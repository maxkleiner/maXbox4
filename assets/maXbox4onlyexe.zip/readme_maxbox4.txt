*****************************************************************
Release Notes maXbox 4.7.6.20 Dez 2022 mX476
****************************************************************
Add 72 Units + 21 Tutorials

1441 unit uPSI_neuralgeneric.pas; CAI
1442 unit uPSI_neuralthread.pas; CAI
1443 unit uPSI_uSysTools; TuO
1444 unit upsi_neuralsets; mX4
1445 unit uPSI_uWinNT.pas mX4
1446 unit uPSI_URungeKutta4.pas ICS
1447 unit uPSI_UrlConIcs.pas ICS
1448 unit uPSI_OverbyteIcsUtils.pas ICS
1449 unit uPSI_Numedit2 mX4
1450 unit uPSI_PsAPI_3.pas mX4
1451 unit uPSI_SeSHA256.pas
1452 unit IdHashMessageDigest_max2;
1453 unit uPSI_BlocksUnit.pas
1454 unit uPSI_DelticsCommandLine.pas
1455 unit uPSI_DelticsStrUtils;
1456 unit uPSI_DelticsBitField;
1457 unit uPSI_DelticsSysUtils;
1458 unit uPSI_ALIniFiles2.pas
1459 unit uPSI_StarCalc2.pas
1460 unit uPSI_IdHashMessageDigest2.pas
1461 unit uPSI_U_Splines;
1462 unit uPSI_U_CoasterB.pas;
1463 U_SpringMass2.pas
1464 uPSI_MARSCoreUtils;
1465 unit uPSI_clJsonParser.pas
1466 unit uPSI_SynHighlighterPython.pas
1467 unit uPSI_DudsCommonDelphi;
1468 unit uPSI_AINNNeuron;
1469 unit uPSI_PJConsoleApp2;
1470 unit uPSI_PJPipeFilters2;
1471 unit uPSI_uHTMLBuilder;
1472 unit uPSI_PJPipe2;
1473 uPSI_WinApiDownload,
1474 uPSI_pxQRcode,    //beta
1475 unit uPSI_neuralplanbuilder2
1476 unit uPSI_DelphiZXingQRCode;
1477 unit uPSI_RestJsonUtils;
1478 unit UtilsTimeCode;
1479 unit uPSC_classes2.pas; //TList
1480 unit uPSC_std2.pas      
1481 unit uPSI_maxIniFiles.pas
1482 unit uROPSImports.pas
1483 unit uROPSServerLink.pas 
1484 unit uPSI_KLibUtils;
1485 unit uPSI_PathFunc2;  //inno setup
1486 unit KLibVC_Redist.pas; 
1487 unit HTTPApp2.pas; 
1488 unit uPSI_XCollection2; 
1489 unit uPSI_KLibWindows;
1490 unit KlibConstants;
1491 unit uPSI_AzuliaUtils.pas
1492 unit uPSI_ALHttpClient2;
1493 unit uPSI_ALWininetHttpClient2;
1494 unit uPSI_UtilsMax41.pas
1495 unit uPSI_JclSysUtils1;
1496 unit uPSI_RestUtils;
1497 unit uPSI_TeEngine2.pas
1498 unit uPSI_Chart2.pas; (uPSI_TeCanvas2.pas)
1499 unit uPSI_PSResources.pas
1500 unit uPSI_TeCanvas2_1.pas
1501 unit uPSI_DataSetConverter4DUtil;
1502 unit uPSI_neuralfit2.pas;
1503 unit uPSI_SynCrtSock.pas
1504 uPSI_RunElevatedSupport.pas
1505 unit synTHttpRequest.pas;
1506 unit uPSI_VelthuisFloatUtils.pas
1507 unit HttpConnection.pas
1508 unit uPSI_HttpConnectionWinInet.pas
1509 unit UHexUtils.pas
1510 unit UExeFileType.pas
1511 unit uPSI_UConsoleApp.pas 
1512 unit uPSI_CompilersURunner.pas

Total of Function Calls: 36141
SHA1: 4.7.6.20 B2B44FC20DA22111EF81553B94B0B903B9D7FA7A
CRC32: 1511CC43 32.4 MB (34,014,488 bytes)
Compilation Timestamp 2022-12-08 10:01:05 UTC Signing time 08 Dec 2022 11:12:55
Entry Point 24902184 - Contained Sections 10  
ZIP maxbox4.zip SHA1: E11AC127708714557F1B74D6CB168F06B8CC6348

****************************************************************
Release Notes maXbox 4.7.5.90 VI November 2021 mX475
****************************************************************
Add 18 Units + 5 Tutorials

1423 uPSI_SingleList.pas; TSingleListClass
1424 unit uPSI_AdMeter.pas; Async Professional
1425 unit uPSI_neuralplanbuilder; CAI
1426 unit uPSI_neuralvolume.pas; CAI
1427 unit uPSI_neuralvolumev.pas; CAI
1428 unit uPSI_DoubleList4; CapJack
1429 unit uPSI_ByteListClass; CapJack
1430 unit uPSI_flcVectors4; FLC5
1431 unit uPSI_flcMatrix4;  FLC5
1432 uPSI_CurlHttpCodes.pas
1433 unit uPSI_NeuralNetwork.pas; CAI
1434 unit unit uPSI_neuralfit; CAI
1435 unit uPSI_neuraldatasets; CAI
1436 unit uPSI_neuraldatasetsv.pas CAI
1437 uPSI_flcFloats.pas FLC5
1438 unit UBigIntsForFloatV4.pas DFF
1439 unit uPSI_CustApp.pas Pas2js
1440 unit uPSI_NeuralNetworkCAI.pas CAI

Total of Function Calls: 34807
SHA1: of 4.7.5.90  96DCDE2028125E00B67E42A801721AC513A5EAFC
CRC32: BBC3A7E5 30.4 MB (31,974,216 bytes)

****************************************************************
Release Notes maXbox 4.7.5.80 July 2021 mX47
****************************************************************
Add 20 Units + 8 Tutorials

1403 unit uPSI_SemaphorGrids;
1404 unit uXmlDates2;
1405 unit uPSI_JclTimeZones;
1406 unit uPSI_XmlDocRssParser.pas
1407 unit uPSI_RssParser.pas
1408 uPSI_SimpleParserRSS.pas
1409 unit uPSI_SimpleRSSUtils;
1410 unit uPSI_RssModel;     _BlueHippo
1411 unit uPSI_StrUtil;      _FIBPlus
1412 unit uPSI_TAChartUtils; _TEE
1413 unit uPSI_PythonEngine.pas _P4D_Beta
1414 unit uPSI_VclPythonGUIInputOutput;
1415 unit uPSI_VarPyth;
1416 unit JclUsesUtils; 
1417 unit uPSI_cParameters;
1418 unit uPSI_WDCCMisc; (uPSI_cFileTemplates);
1419 uPSI_WDCCOleVariantEnum.pas
1420 unit uPSI_WDCCWinInet.pas  _WDCC
1421 uPSI_PythonVersions.pas
1422 unit uPSI_PythonAction.pas

SIRegister_TFastStringStream(CL);
procedure LoadJPEGResource(image1: TImage; aJpgImage: string);
function CreateDOSProcessRedirected3(const CommandLine, InputFile, OutputFile,
                                           ErrMsg: string): Boolean;
function SysCharSetToStr(const C: TSysCharSet): AnsiString;
function StrToSysCharSet(const S: AnsiString): TSysCharSet;
Procedure MaskFPUExceptions( ExceptionsMasked : boolean; MatchPythonPrecision: Boolean);
Function GetOleVariantEnum( Collection : OLEVariant) : IGetOleVariantEnum);
Function GetOleVariantArrEnum( Collection : OLEVariant) : IGetOleVariantEnum);
Function GetRegisteredPythonVersions : TPythonVersions');

Total of Function Calls: 33848
SHA1: of 4.7.5.80  3E38A48072D4F828A4BE4A52320F092FE50AE9C3
CRC32: B6F69E19 29.8 MB (31,344,456 bytes)

****************************************************************
Release Notes maXbox 4.7.5.20 Jan 2021 mX47
****************************************************************
Add 25 Units + 4 Tutorials

1277 unit uPSI_SystemsDiagram.pas  Dendron
1278 unit uPSI_qsFoundation.pas    Dendron
1279 uPSI_JclStringLists2          JCL 	
1280 uPSI_cInternetUtils2          FLC
1281 uPSI_cWindows.pas	           FLC
1282 uPSI_flcSysUtils.pas  +TBytes utils
1283 unit uPSI_RotImg.pas          DA 
1284 uPSI_SimpleImageLoader.pas    LAZ
1285 uPSI_HSLUtils.pas             LAZ
1286 uPSI_GraphicsMathLibrary.pas  EF
1287 unit uPSI_umodels.pas         DMath
1288 uPSI_flcStatistics.pas        FLC5
1289 uPSI_flcMaths.pas             FLC5
1290 uPSI_flcCharSet.pas
1291 uPSI_flcBits32.pas
1292 uPSI_flcTimers.pas
1293 uPSI_cBlaiseParserLexer.pas
1294 uPSI_flcRational.pas
1295 uPSI_flcComplex.pas
1296 unit uPSI_flcMatrix (uPSI_flcVectors.pas)
1297 unit uPSI_flcStringBuilder.pas
1298 unit PJResFile_Routines;
1299 uPSI_flcASCII.pas
1300 uPSI_flcStringPatternMatcher;
1301 unit uPSI_flcUnicodeChar.pas

Totals of Function Calls: 33282
SHA1: of 4.7.5.20 D82EAD01C58738887661428F94B207DB1D8FAEB5
CRC32: 203C82F0  29.5 MB (31,012,768 bytes

****************************************************************
Release Notes maXbox 4.7.4.64 June 2020 mX47
****************************************************************

1254 unit uPSI_MaskEdit.pas    FCL
1255 unit uPSI_SimpleRSSTypes; BlueHippo
1256 unit uPSI_SimpleRSS;      BlueHippo
1257 unit uPSI_psULib.pas      Prometheus
1258 unit uPSI_psUFinancial;   Prometheus
1259 uPSI_PsAPI_2.pas          mX4
1260 uPSI_PersistSettings_2    mX4
1261 uPSI_rfc1213util2.pas     IP
1262 uPSI_JTools.pas           JCL
1263 unit uPSI_neuralbit.pas   CAI
1264 unit uPSI_neuralab.pas    CAI
1265 unit uPSI_winsvc2.pas     TEK
1266 unit uPSI_wmiserv2.pas    TEK
1267 uPSI_neuralcache.pas      CAI
1268 uPSI_neuralbyteprediction CAI
1269 unit uPSI_USolarSystem;   glscene.org
1270 uPSI_USearchAnagrams.pas  DFF
1271 uPSI_JsonsUtilsEx.pas     Randolph
1272 unit uPSI_Jsons.pas       Randolph
1273 unit uPSI_HashUnit;       DFF
1274 uPSI_U_Invertedtext.pas   DFF
1275 unit uPSI_Bricks;         Dendron
1276 unit uPSI_lifeblocks.pas  Dendron

Totals of Function Calls: 32633
SHA1: of 4.7.4.64 DA4C716E31E2A4298013DFFBDA7A98D48650B0C7
CRC32: 3EB27A87:  28.2 MB (29,608,248) bytes


****************************************************************
Release Notes maXbox 4.7.1.82 Dez 2019 mX47
****************************************************************
add Tutor 57 - 72 
add NoGUI Shell Tutorial 71 and 46 Units

 1307 unit uPSI_statmach,   {StateMachine} 
 1308 uPSI_uTPLb_RSA_Primitives,
 1309 unit uPSI_UMatrix,    //for Tensorflow dll
 1310 uPSI_DXUtil,
 1311 uPSI_crlfParser,
 1312 unit uPSI_DCPbase64;
 1313 unit uPSI_FlyFilesUtils;
 1314 uPSI_PJConsoleApp.pas
 1315 uPSI_PJStreamWrapper.pas
 1316 uPSI_LatLonDist,    //DFF
 1317 uPSI_cHash2.pas     //Fundamentals SHA512
 1318 uPSI_ZLib2.pas      //compressor
 1319 unit uPSI_commDriver
 1320 unit uPSI_PXLNetComs.pas   //PXL
 1321 unit uPSI_PXLTiming.pas    //PXL
 1322 uPSI_Odometer.pas
 1323 unit uPSI_UIntList2;
 1324 uPSI_UIntegerpartition.pas
 1325 unit uPSI_idPHPRunner.pas  //prepare for PHP4D
 1326 unit uPSI_idCGIRunner.pas
 1327 uPSI_DrBobCGI,             //4.7.1.20
 1228 uPSI_OverbyteIcsLogger,
 1229 uPSI_OverbyteIcsNntpCli,  testset
 1230 uPSI_OverbyteIcsCharsetUtils,
 1231 uPSI_OverbyteIcsMimeUtils,
 1232 uPSI_OverbyteIcsUrl(CL: TPSPascalCompiler);
 1233 uPSI_uWebSocket.pas
 1234 uPSI_KhFunction.pas
 1235 uPSI_ALOpenOffice.pas
 1236 unit uPSI_ALLibPhoneNumber
 1237 unit uPSI_ALPhpRunner2;
 1238 unit uPSI_ALWebSpider2;
 1239 unit uPSI_ALFcnHTML2; // RunJavaScript2
 1240 unit uPSI_ALExecute2.pas
 1241 uPSI_ALIsapiHTTP.pas
 1242 uPSI_ALOpenOffice_Routines
 1243 unit uPSI_uUsb;
 1244 uPSI_uWebcam.pas
 1245 uPSI_PersistSettings.pas //fixing & refactoring
 1246 uPSI_uTPLb_MemoryStreamPool.pas
 1247 uPSI_uTPLb_Signatory.pas
 1248 unit uPSI_uTPLb_Constants.pas  //TurboPower
 1249 uPSI_uTPLb_Random.pas
 1250 unit uPSI_uTPLb_PointerArithmetic;
 1251 unit uPSI_EwbCoreTools.pas
 1252 unit uPSI_EwbUrl.pas
 1253 unit uPSI_SendMail_For_Ewb.pas

TidCGIRunner component allows to execute CGI scripts using 
Indy TidHTTPServer component. 

// Project:     1307 State Machine
// Module:      statmach.pas
// Description: Visual Finite State Machine.
// Version:     2.2a,  Release: 6 preprocessor, compiler, interpreter
function VarArrayToStr(const vArray: variant): string;
function GetWMIObject(const objectName: String): IDispatch; //create WMI instance
function GetAntiVirusProductInfo: TStringlist;

Totals of Function Calls: 32147
SHA1: of 4.7.1.82 431DACFCEB0739DC3A6844BB3DBE0084DE90F1F1
CRC32: E2D13D3F 27.6 MB (28,996,000 bytes)
maxbox4.zip sha1: 46e51c65b560986346f27314cd303f79a7ff05d5

****************************************************************
Release Notes maXbox 4.6.2.10 Jan 2018 mX46
****************************************************************
add Tutor 56 Neural Network -Python Checker
add intenet radio: http://europe1.radio.net/

1302 uPSI_ULog.pas
1303 uPSI_UThread.pas
1304 uPSI_UTCPIP.pas
1305 Synapse_OpenSSLv11
1306 PascalCoin configuration config.inc

Totals of Function Calls: 31475
SHA1: of 4.6.2.10 18200555A3407F8F7A40782618C9E4AE15590849
CRC32: 0113AD6D 27.1 MB (28,493,264 bytes)

****************************************************************
Release Notes maXbox 4.5.8.10 Jan 2018 Ocean8 mX4
****************************************************************
add 15 units XMLDoc XMLIntf, ADO_Recordset CryptoLib4, XMLW
add 6 Tutors: #50-55 (Microservice, CryptoAPI, maXML, ASCIItalk)  
switch: DEP Data Execution Prevention
new code indent guide INDENT - stop in inifile INDENT=N
TFannNetwork encapsulates the Fast Artificial Neural Network- fann.sourceforge.net
DLL needed: fannfloat.dll
https://sourceforge.net/projects/maxbox/files/Examples/fannfloat.dll/download
https://maxbox4.wordpress.com/

1283 uPSI_uTPLb_StreamCipher.pas
1284 uPSI_uTPLb_BlockCipher.pas
1285 uPSI_uTPLb_Asymetric.pas
1286 uPSI_uTPLb_CodecIntf.pas
1287 uPSI_uTPLb_Codec.pas
1288 uPSI_ADOInt.pas
1289 uPSI_MidasCon.pas
1290 uPSI_XMLDoc.pas
1291 uPSI_XMLIntf.pas
1292 uPSI_ProxyUtils.pas
1293 unit uPSI_maxXMLUtils2;
1294 unit_StDict_Routines(TPSExec);
1295 unit uPSI_Hashes2
1296 unit uPSI_IdCoderHeader;
1297 unit uPSI_BackgroundWorker2
1298 uPSI_uMRU.pas
1299 unit FANN.pas
1300 unit uPSI_FannNetwork.pas
1301 unit uPSI_RTLDateTimeplus.pas

Totals of Function Calls: 31422
SHA1: 4.5.8.10   FFF8300142CE582DFCC8E15489AD7D5EE2E08062
CRC32: A013C5BC  27.1 MB (28,465,616 bytes)

****************************************************************
Release Notes maXbox 4.2.6.10 Aug 2017 Ocean8 mX4
****************************************************************
add 10 units + 260 functions SHA256 -StreamStorage -WMI 3 etc.
add 6 Tutors: #48 (Microservice) - #53 (Realtime UML) 
new Style: menu//Output/Darkcolor
http://www.softwareschule.ch/images/maXbox4_darkcolor3.png

1273 uPSI_CromisStreams, (TStreamStorage)
1274 unit uPSI_Streams,
1275 uPSI_BitStream,
1276 uPSI_UJSONFunctions.pas
1277 uPSI_uTPLb_BinaryUtils.pas
1278 unit uPSI_USha256.pas  //PascalCoin Blockchain
1279 uPSI_uTPLb_HashDsc.pas
1280 uPSI_uTPLb_Hash.pas
1281 SIRegister_Series(X); (uPSI_Series) //4.2.6.10
1282 unit uPSI_UTime; (UTime); uPSI_mimeinln2;

Totals of Function Calls: 30725
SHA1: of 4.2.6.10 824E0A2CABE4411F470D6BB8AE1530576A92F684
CRC32: 45AC9AE47 26.8 MB (28,118,480 bytes)

****************************************************************
Release Notes maXbox 4.2.5.10 Feb 2017 Ocean8 mX4
****************************************************************
add 12 units + 584 functions HugeInt-HugeWord Library -SimpleTCP
add 2 Tutors: 47 RSA Crypto - 48 Microservices 

new Style: menu//Output/Darkcolor
http://www.softwareschule.ch/images/maXbox4_darkcolor.png

maxboxdef.ini-file with FONTNAME=Courier New 

1261 unit uPSI_uBild;  //Steganography
1262 unit uPSI_SimpleTCP;
1263 unit uPSI_IdFTPList;
1264 uPSI_uTPLb_CryptographicLibrary.pas
1265 uPSI_uTPLb_RSA_Engine.pas
1266 unit uPSI_cHugeInt.pas
1267 unit uPSI_SimpleTCPServer;
1268 unit uPSI_xBase.pas
1269 unit uPSI_ImageHistogram.pas
1270 unit uP_PersistSettings2;
1271 uPSI_WDosDrivers.pas
1272 unit uPSI_cCipherRSA;

function VarByteArrayOf(const s: string): OleVariant;
Procedure BurnMemoryByteArray2( var array of Byte; BuffLen : integer);
Procedure BurnMemoryString2( var Buff: string; BuffLen : integer);
Procedure MoveStringJV(const Source: string; var Dest : string; Count : Integer);
ClientDataSet: RegisterMethod(function UpdateStatus: TUpdateStatus; 
function bigdiv2(aval1: string; aval2: integer): string;
function modbig(aval: string; amod: integer): integer;  
function bigmod(aval: string; amod: integer): integer;  
function modPowBig3(aval, apow, amod: string): string;');
function BigPowMod(aval, apow, amod: string): string;');
function RSAEncrypt(aval, apow, amod: string): string;');
function RSADecrypt(aval, apow, amod: string): string;');
Function SwitchToThread : BOOL');
Function SetThreadDesktop( hDesktop : HDESK) : BOOL');
Function CloseDesktop( hDesktop : HDESK) : BOOL');
Function GetThreadDesktop( dwThreadId : DWORD) : HDESK');
function SetSyscallHook(): boolean;');
function SetSwapcontextHook(): boolean;');
function UnhookAll(): boolean;');
function getWorld: string;');
function getIPConfigAll: string;');
function getIPConfig: string;');
function WinsockEnabled: Boolean;
function HTTPEncode2(const AStr: string): string;
RSAEncryptStr(const EncryptionType: TRSAEncryptionType; const PublicKey: TRSAPublicKey; const Plain: AnsiString): AnsiString;
 
Totals of Function Calls: 30467
SHA1: of 4.2.5.10 55D33FE9506C66DD2AD94802AE9E838DCAE021AB
CRC32: C5D0EBB7 26.6 MB (27,960,272 bytes)
 

****************************************************************
Release Notes maXbox 4.2.4.80 October 2016 Ocean7 mX4
****************************************************************
add 20 units + 442 functions- WMI Script Type Library - webbox

1241 uPSI_wmiserv.pas {uPSI_SimpleSFTP.pas}
1242 uPSI_WbemScripting_TLB.pas
1243 unit uPSI_uJSON2;
1244 uPSI_RegSvrUtils.pas
1245 unit uPSI_osFileUtil;
1246 unit uPSI_SHDocVw; //TWebbrowser
1247 unit uPSI_SHDocVw_TLB;
1248 uPSC_classes.pas V2
1249 uPSR_classes.pas V2
1250 uPSI_U_Oscilloscope4_2
1251 unit uPSI_xutils.pas
1252 uPSI_ietf.pas
1253 uPSI_iso3166.pas
1254 uPSI_dateutil_real.pas  //Optima ISO 8601
1255 unit uPSI_dateext4.pas
1256 uPSI_locale.pas
1257 file charset.inc  //IANA Registered character sets
1258 unit uPSI_Strings;
1259 unit uPSI_crc_checks;  //ISO 3309 and ITU-T-V42
1260 unit uPSI_extDOS;

SHA1: of 4.2.4.80 15565A557B0F9576AA5F23F2A1D06BE9699A757B
CRC32: FA1F1F25 26.4 MB (27,720,144 bytes)
http://www97.zippyshare.com/v/MECWgB5I/file.html

 function GetCachedFileFromURL(strUL: string; var strLocalFile: string): boolean;
 function IAddrToHostName(const IP: string): string;
 function GetIEHandle(WebBrowser: TWebbrowser; ClassName: string): HWND;
 function GetTextFromHandle(WinHandle: THandle): string;
 procedure Duplicate_Webbrowser(WB1, WB2: TWebbrowser);
 function FillWebForm(WebBrowser:TWebBrowser;FieldName:string;Value:string):Bool; 
 procedure WB_LoadHTML(WebBrowser: TWebBrowser; HTMLCode: string);
 function NetSend(dest, Source, Msg: string): Longint; overload;
 function RecordsetFromXML2(const XML: string): variant;');
 function RecordsetToXML2(const Recordset: variant): string;');
 Function GetCharEncoding( alias : string; var _name : string) : integer');
 Function MicrosoftCodePageToMIMECharset( cp : word) : string');
 Function MicrosoftLangageCodeToISOCode( langcode : integer) : string');
 procedure CopyHTMLToClipBoard(const str: string; const htmlStr: string = '');
 function RFC1123ToDateTime(Date: string): TDateTime;
 function DateTimeToRFC1123(aDate: TDateTime): string;
 procedure CopyHTMLToClipBoard(const str: string; const htmlStr: string);');
 procedure DumpDOSHeader(const h: IMAGE_DOS_HEADER; Lines: TStrings);');
 procedure DumpPEHeader(const h: IMAGE_FILE_HEADER; Lines: TStrings);');
 procedure DumpOptionalHeader(const h: IMAGE_OPTIONAL_HEADER; Lines: TStrings);');
 Function checkSystem: string;
 Function getSystemReport: string;

****************************************************************
Release Notes maXbox 4.2.4.25 June 2016 Ocean5 mX4
****************************************************************
add 16 units and 225 functions- Class Helper- KMemo RTF DOSOutput

 1224 uPSI_IdAntiFreeze.pas
 1225 uPSI_IdLogStream.pas
 1226 unit uPSI_IdThreadSafe;
 1227 unit uPSI_IdThreadMgr;
 1228 unit uPSI_IdAuthentication;
 1229 unit uPSI_IdAuthenticationManager;
 1230 uPSI_OverbyteIcsConApp
 1231 unit uPSI_KMemo;
 1232 unit uPSI_OverbyteIcsTicks64;
 1233 unit uPSI_OverbyteIcsSha1.pas
 1234 unit uPSI_KEditCommon.pas
 1235 unit uPSI_UtilsMax4.pas
 1236 unit uPSI_IdNNTPServer;
 1237 unit uPSI_UWANTUtils;
 1238 unit uPSI_UtilsMax5.pas;
 1239 unit uPSI_OverbyteIcsAsn1Utils;
 1240 unit uPSI_IdHTTPHeaderInfo; //mX response headers

SHA1: of 4.2.4.25 A52ACF844808285D8EE978637365B74B3C7C342F
CRC32: CB882FFC  26.0 MB (27,276,288 bytes) 

****************************************************************
Release Notes maXbox 4.2.2.90 April 2016 Ocean2 mX4
****************************************************************
add 12 units and 20 functions - minor bugfixes - coolcode
http://max.kleiner.com/boxart.htm

 1212 unit uPSI_MapFiles.pas    //map stream of memory-mapped files
 1213 unit uPSI_BKPwdGen,       //Password Generator
 1214 unit uPSI_Kronos,         //Big chrono date time library
 1215 unit uPSI_TokenLibrary2;  //C++ TokenLib
 1216 uPSI_KDialogs,            //KFramework
 1217 uPSI_Numedit,             //Num Component
 1218 unit uPSI_StSystem2;      //Low Level Routines
 1219 unit uPSI_KGraphics;      //KFramework
 1220 uPSI_KGraphics_functions; //KFramework
 1221 uPSI_umaxPipes.pas        //Simple Pipe Server
 1222 unit uPSI_KControls;      //KFramework
 1223 unit SysUtils_max2;       //mX4 BaseLib

****************************************************************
Release Notes maXbox 4.2.0.80 April 2016 Ocean mX4
****************************************************************
This is an upgrade to mX3 app files dir, if you want all examples/docs for this mX4 
you have to download mX3 first and then copy mX4 files in it too.
Otherwise you already own mX3 on disk just copy new files (save maxboxdef.ini first).
All functions & object: maxbox_functions_all.pdf
News: Add 5 Units, 1 Tutor, Pipe Libraray2, KLog, FPlot42
1207 unit uPSI_CPUSpeed.pas
1208 uPSI_RoboTracker.pas
1209 unit uPSI_NamedPipesImpl.pas
1210 unit uPSI_KLog.pas
1211 unit uPSI_NamedPipeThreads.pas
new added functions
-----------------------------------------------------
function CPUSpd: String;
function CPUSpeed: String;
function BigFib(n: integer): string;  //BigFibo
function BigFac(n: integer): string;  //BigFact
function UpTime: string;
Function NetLogon( const Server, User, Password : WideString; out ErrorMessage : string) : Boolean');
Function NetLogoff( const Server, User, Password : WideString) : Boolean');
Procedure ErrorNamedPipe( const Message : string)');
procedure BroadcastChange; //method that broadcasts the necessary message WM_SETTINGCHANGE
Function WriteFile2( hFile : THandle; const Buffer, nNumberOfBytesToWrite : DWORD; var lpNumberOfBytesWritten : DWORD; lpOverlapped : Tobject) : BOOL');
Function ReadFile2( hFile : THandle; var Buffer, nNumberOfBytesToRead : DWORD; var lpNumberOfBytesRead : DWORD; lpOverlapped : Tobject) : BOOL');
// Security helper functions
procedure InitializeSecurity(var SA: TSecurityAttributes);
procedure FinalizeSecurity(var SA: TSecurityAttributes);
// Pipe helper functions
procedure CheckPipeName(Value: string);
procedure ClearOverlapped(var Overlapped: TOverlapped; ClearEvent: Boolean);
procedure CloseHandleClear(var Handle: THandle);
function ComputerName2: string;
procedure DisconnectAndClose(Pipe: HPIPE; IsServer: Boolean = True);
function EnumConsoleWindows(Window: HWND; lParam: Integer): BOOL; stdcall;
procedure FlushMessages;
function IsHandle(Handle: THandle): Boolean;
procedure RaiseWindowsError;
function CharSetToCP(ACharSet: TFontCharSet): Integer;
function CPToCharSet(ACodePage: Integer): TFontCharSet;
function TwipsToPoints(AValue: Integer): Integer;
function PointsToTwips(AValue: Integer): Integer;
procedure LoadGraphicFromResource(Graphic: TGraphic; const ResName: string; ResType: PChar);

///////////////////////////////////////////////////////////////////////////////
// Object instance functions
///////////////////////////////////////////////////////////////////////////////
function AllocateHWnd(Method: TWndMethod): HWND;
procedure DeallocateHWnd(Wnd: HWND);
MessageBox(0,PChar('CPU speed is '+CPUSpd+' MHz'),'CPU Speed Check',MB_IconInformation+MB_OK);
CL.AddTypeS('TKLogEvent', 'Procedure ( Sender : TObject; Code : TKLogType; const Text : string)');
AddRegisteredVariable('FormatSettings','TFormatSettings');  //at sysutils!
AddRegisteredVariable('mouse','TMouse');  //at controls
CL.AddTypeS('HPIPE', 'THandle');
SHA1: of 4.2.0.80 638E7412750AB0ECF14F2A5515BC4A2DE561EAC2
CRC32: 7C91FD2A  Exe size: 26,650,112
https://www.virustotal.com/en/file/584ca53d6dd8f7de17d0a1959bf78aad04697cf0ad7b3f23aee90b5ff720ede1/analysis/1460194451/
Update for Windows 10 Version 1511 for x64-based Systems (KB3140741)

