maXbox5 alpha version 5.0.1.21 beta
maXbox5 alpha version 5.0.1.22 beta Ocean550
maXbox5 alpha version 5.0.1.22 beta Ocean560
maXbox5 beta  version 5.0.2.24 beta Ocean580  20/11/2023
maXbox5 beta  version 5.0.2.28 beta Ocean590  25/11/2023
maXbox5 beta  version 5.0.2.30 beta Ocean600  28/11/2023
maXbox5 beta  version 5.0.2.30 beta Ocean600  06/12/2023
maXbox5 beta  version 5.0.2.31 beta Ocean610  11/12/2023
maXbox5 beta  version 5.0.2.40 beta Ocean620  16/12/2023
maXbox5 beta  version 5.0.2.40 beta Ocean640  22/12/2023
maXbox5 beta  version 5.0.2.60 beta Ocean660  02/01/2024
maXbox5 beta  version 5.0.2.70 beta Ocean670  05/01/2024
maXbox5 beta  version 5.0.2.80 beta Ocean680  17/01/2024
maXbox5 beta  version 5.0.2.90 beta Ocean690  28/01/2024 🐞
maXbox5 beta  version 5.0.2.95 beta Ocean690  01/02/2024 🐞
maXbox5 beta  version 5.0.3.40 beta Ocean710  04/02/2024 🐞
maXbox5 beta  version 5.0.3.60 beta Ocean720  12/02/2024 🐞
maXbox5 beta  version 5.0.4.60 beta Ocean740  15/02/2024 🐞
maXbox5 beta  version 5.0.4.70 beta Ocean750  18/02/2024 🐞
maXbox5 beta  version 5.0.4.70 PE XN beta Ocean750  24/02/2024 🐞
maXbox5 beta  version 5.1.4.70 PE XN beta Ocean770  25/02/2024 🐞
maXbox5 beta  version 5.1.4.80 UnitExplor Ocean780  01/03/2024 🐞
maXbox5 beta  version 5.1.4.80 UnitExplor Ocean800  03/03/2024 🐞
maXbox5 beta  version 5.1.4.80 UnitExplor Ocean820  08/03/2024 🐞
maXbox5 beta  version 5.1.4.80 UnitExplor Ocean840  10/03/2024 🐞
maXbox5 beta  version 5.1.4.90 UnitExplor Ocean840  15/03/2024 🐞
maXbox5 beta  version 5.1.4.90 UnitExplor Ocean860  21/03/2024 🐞
maXbox5 beta  version 5.1.4.95 UnitExplor Ocean870  17/04/2024 🐞
maXbox5 beta  version 5.1.4.95 II WebUtil Ocean880  19/04/2024 🐞



------------------------------------------------------
This file was provided by: https://github.com/maxkleiner/maXbox4/tree/master/source2023_1_64bitbox

Windows 11, version 23H2
2024-04 Cumulative Update for Windows 11 Version 23H2 for x64-based Systems (KB5036893)
2024-04 Cumulative Update for .NET Framework 3.5 and 4.8.1 for Windows 11, version 23H2 for x64 (KB5036620)

If you downloaded it from somewhere else, please let us know: maxkleiner1@gmail.com
https://maxbox4.wordpress.com/
Primo loco - Fac totum  - Actas volat

maxbox5.zip has 260 files

Viruscheck as clean at:
https://www.virustotal.com/gui/file/d0c67eddb6494d8115f2f3e79babf962c9b577708306d1e904a4df6d917466fd/detection
https://www.virustotal.com/gui/file/30c690db62436ea717547a62b5f3eef83308159f6d51f6e87d87694dce24a949/detection
https://www.virustotal.com/gui/file/f1d09d3d7a98ac8b91618d47bdf7625867fb2b12e202d72f59ac312967257eb3/detection
https://www.hybrid-analysis.com/sample/f1d09d3d7a98ac8b91618d47bdf7625867fb2b12e202d72f59ac312967257eb3
https://www.virustotal.com/gui/file/b4c41dd487f28e2c3cad2285f048b640579f5a4b8ce08d889e99b7c2122fe566?nocache=1
https://www.virustotal.com/gui/file/21c11f025db024bdfbadf890c4d495f38a418fac4baefbd0af6a5c687e6055a2?nocache=1
https://www.virustotal.com/gui/file/6c0883d1ac971b54b026e776b7d47a6d3ffa52b2083f18c85ccdbcf1f5b0b3e8/detection
https://www.virustotal.com/gui/file/2a965afa61b2717ae0af5d683cb7b9d0fa17356027f68919751ea748dedfb90c/detection
https://www.virustotal.com/gui/file/f2d163a0d20beec76d860dd3376d3fe7088afd878cedb1d3a2a4ada56c36916f/detection
https://www.virustotal.com/gui/file/4580bf9ec64db20fc102b539ccff9fa7ecf0a8a1648d2ff147df83ca34768e07/detection
https://www.virustotal.com/gui/file/442681ad017536c569230b5f78d8fd4dcebd9e2adc1559d50e68ac9a0e57a8aa/detection
https://metadefender.opswat.com/results/file/bzI0MDMwMzF6cWNBQVpoOEJwTjlFWkJ2cDc_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/442681ad017536c569230b5f78d8fd4dcebd9e2adc1559d50e68ac9a0e57a8aa

https://www.virustotal.com/gui/file/b985359cba2be29838b8dafdca41f9042d919254e59d36def159b49f6d078516/detection
https://www.virustotal.com/gui/file/27a2f95c2c344a59b90b46bf37dcfdc61f59c756abfc4660fc8916b7d7183138/detection
https://www.virustotal.com/gui/file/c757ee7323a60e67bf2716a06dc8bbde8e79cc4b7dd0b6e632d42c6a9e286def/detection
https://www.virustotal.com/gui/file/04ca4906fa42471a019f961551558d06d748223efc1a8e33e296f84fe88b6913/detection
https://metadefender.opswat.com/results/file/bzI0MDIyNWt2bFZIWFdHQUZRY2J2a0ROUm0_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/04ca4906fa42471a019f961551558d06d748223efc1a8e33e296f84fe88b6913

https://www.virustotal.com/gui/file/ed66799c5b76fcccfca1515b0188d5f8ac41dce49f0410ba76ffb913d2df8955/detection
https://metadefender.opswat.com/results/file/bzI0MDIyNGJOcXh5VDFMallxaTBMd1YtbGg_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/ed66799c5b76fcccfca1515b0188d5f8ac41dce49f0410ba76ffb913d2df8955

https://www.virustotal.com/gui/file/998280f98383457e9148bb73f0787b25f3173af1aa52a854dcd78cc52bb0df2b/detection
https://metadefender.opswat.com/results/file/bzI0MDIxOElhRDNoUVBueXJIdDBvU0pla0k_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/998280f98383457e9148bb73f0787b25f3173af1aa52a854dcd78cc52bb0df2b

https://www.hybrid-analysis.com/sample/998280f98383457e9148bb73f0787b25f3173af1aa52a854dcd78cc52bb0df2b/65d217cfbed42b0ab202c037
https://www.virustotal.com/gui/file/5439e647a22a33aa87caaea96adc16f867c78321ea5249fc3a92a7a6fe2980fa/detection
https://metadefender.opswat.com/results/file/bzI0MDIxNkUtVks1emF2OVhMY2laazFwa3o_mdaas/regular/overview

https://www.virustotal.com/gui/file/928326a4211b50edc4fcd88aa001d19c69d1bc33292dc121c4c7d7d5a4c1eaf9/detection
https://metadefender.opswat.com/results/file/bzI0MDIxNUxvY2xxWFN2VDhHSHdKZ0xsbFE_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/928326a4211b50edc4fcd88aa001d19c69d1bc33292dc121c4c7d7d5a4c1eaf9
https://www.virustotal.com/gui/file/90de12e5f0ff2307023ff96644be35a976ea1ea3df497e1060cca3f11c5918bc/detection
https://metadefender.opswat.com/results/file/bzI0MDIxMktiTUpkWnl5YmtaVjh3OEk2Rl9w_mdaas/regular/overview
https://www.hybrid-analysis.com/sample/90de12e5f0ff2307023ff96644be35a976ea1ea3df497e1060cca3f11c5918bc/65ca1e1c20f2c83e7a086b7b
https://www.virustotal.com/gui/file/4bf74727ef80b99a10ef7daf8a0c2be4b54415387df87cf57ed9d334ca826088/detection
https://www.virustotal.com/gui/file/7d0f6a42f1fc75f82bace5ce1704018839b2366b7689a40b1bef0f39fb169d96/detection
https://www.hybrid-analysis.com/sample/5c6fd68214935dcbe13ed14529a265d2d4a12a2cfabbdb2c43754118bcecc615
https://www.virustotal.com/gui/file/5c6fd68214935dcbe13ed14529a265d2d4a12a2cfabbdb2c43754118bcecc615/detection
https://www.virustotal.com/gui/file/066f5aae5692f24e96ab3660c3f3a9d5d36f8eb3445f095a49282727d5c5ded6/detection
https://www.virustotal.com/gui/file/be155feccff2bb8aa79bf50cdb2c809ec74937fd7afd0a35311bd33feb14ae51/details
https://www.virustotal.com/gui/file/a0cb07f0ada81f317b8bdda7ada408619624a1148347c5365ed3fa2d8fae4862/detection
https://www.virustotal.com/gui/file/faaa1ecf193afb5bfe1f3dd489ca830db38a3ad67ca0e2cad54fc0256d45d40e/detection
https://www.virustotal.com/gui/file/84dd7e157da55d608cba95feb7d705ccda48cdf7c980fec964c183198741e0db/detection
https://www.virustotal.com/gui/file/da34199785ae5371e2cf8a23a12b68295f7c968ba0c8a24f367baf0c5f091439/detection
https://metadefender.opswat.com/results/file/bzI0MDEwMTJJSTN0R3h5dHV6MS1wdzBpLWo_mdaas/regular/sandbox/details
https://www.virustotal.com/gui/file/f64df137d0ae2fc724d3bbd419c850b9262554776aadfed03c0b5cb27e7806bb/detection
https://www.virustotal.com/gui/file/f58817db55eabd401ee37539434f0fdcb0453eddd3864aac0668c48265e720f2/detection
https://www.virustotal.com/gui/file/048dae8dab0df4bc6b3f77233a3a4c8f2ca0a56517a9861bb94c2179cfdb87fe/detection
https://www.virustotal.com/gui/file/0d31956549a268645a2616f0c358772042f44f69714d4f0de6ba455d99f40855/detection
https://www.hybrid-analysis.com/sample/a6215ee348a7434b90f215362731337c36bb6e711c61d5cf5fdc213e6e9ee36f/657191c420cba00ce108a768
https://www.virustotal.com/gui/file/a6215ee348a7434b90f215362731337c36bb6e711c61d5cf5fdc213e6e9ee36f/detection
https://www.hybrid-analysis.com/sample/f999d8522736906d9c93c1867ec536c3dbdd6ec8a939982572534835f7253743
https://www.virustotal.com/gui/file/f999d8522736906d9c93c1867ec536c3dbdd6ec8a939982572534835f7253743/detection
https://www.virustotal.com/gui/file/3e1dee4a7d1120b8b706d6d08bfc756fe8a13abd4df0317958f7b6a0e4c8ee0d/detection
https://www.virustotal.com/gui/file/cae3a4eae8f3bcfbd972c4675894891f35d5ef97c326624e0e8b2f585aea0911?nocache=1
https://www.virustotal.com/gui/file/ee1d20b3e44855308813d54b3768a97c842524e1a021ec6adfacb022e523a40f?nocache=1
https://www.virustotal.com/gui/file/00e6bb40d6e3ab176e5d9024b52975d710df5ad0cdfb79e5ce255db8a386bf10?nocache=1
https://www.virustotal.com/gui/file/ffd69c30dbe891a029451899400be4409ebf78718ec8fc2ec5ceaf13a01238d8/detection
https://www.virustotal.com/gui/file/1058b2b6004a73ebd6d4b3ecc54b36dec94be97c0c2c75e406d266712b3db011/detection
https://www.virustotal.com/gui/file/0c0851d0ebe022fa42360465d803cdc11e6ae81b688ac3a8a4f06e6203914ff2/detection
https://www.virustotal.com/gui/file/67dee7d584bd6d53bef4f6891b9b73521302cdc66a2c4cc7d8ea96939bed6450/detection
https://www.virustotal.com/gui/file/34040f3dd5f929ef4b3142bf3b2a206057ef58956595ecfa7ab2cd91e4e66ee5/detection
https://www.virustotal.com/gui/file/ce681d23c7e3ec6febc0af5e7fd87674d65e63f595641e87092c01957a27f894/detection
https://www.virustotal.com/gui/file/82591ab1b613368f3a4c235300d79bc958867244326292d9ec940619dc874afe/details
https://www.virustotal.com/gui/file/2100cc8d605b5396f3acdb4c235615281b3938767270517f102afc6bb48c582a/detection
https://www.virustotal.com/gui/file/3659aa9ef8e9e85da0bef15c6f9af88da869023c549b98688cba7a6062966dcf/detection
https://www.virustotal.com/gui/file/dc542ca67bec024448447e01e31197cda60374e47b7f4c61ece2d79c8312e375/detection
https://www.virustotal.com/gui/file/5af156d782e755b35fccd72dcb4cea8729c50c332fc00e69272028297bf2373d/details

https://github.com/Delphi-FPC-Lazarus/DelphiLazarus_UnicodeUtil/blob/master/unicode_util_unit.pas
The individual DLL files like dmath64.dll are provided free of charge with the understanding that the user is familiar with their use.

If you need further information, please see:
https://maxbox4.wordpress.com/
or ask your question in the forum:
https://github.com/maxkleiner/maXbox4/issues
https://forum.dll-files.com/

DISCLAIMER AND LIMITATION OF LIABILITY

The Following Refers to all Files with the Extension of "dll" or dlls compressed as "zip" or files as "exe" or compressed as "zip".

All files are provided on an as is basis. No guarantees or warranties are given or implied. Downloading files from this site is free of charge and the user assumes all risks of any damages that may occur, including but not limited to loss of data, damages to hardware, or loss of business profits. We do our best to ensure that all files are virus-free using available means. However, all files have not been tested for functionality or contamination. Many have been sent to us by visitors like yourself. Thus, we suggest that you do a virus scan using an up-to-date version of an anti-virus program before use. Please use at your own risk.setuptools~=68.2.0
PyQt5~=5.15.10
pyqtgraph~=0.13.3
xmltodict~=0.13.0
networkx~=3.1
pytest~=8.0.0
pytest-cov~=4.1.0

 writeln(GETDOSOutput('cmd.exe /c fc units1.txt units2.txt',
                                         'C:\maxbox\maxbox51\examples'));
  
Diff from 5.1.4.90 to 5.1.4.95

Comparing files units1.txt and UNITS2.TXT
***** units1.txt
DBPlatform
DBXCharDecoder_
DBXCustomDataGenerator
***** UNITS2.TXT
DBPlatform
DBXCustomDataGenerator
*****

***** units1.txt
IdMIMETypes
IdModBusClient
IdModBusServer
IdMultipartFormData
***** UNITS2.TXT
IdMIMETypes
IdMultipartFormData
*****

***** units1.txt
IdStrings
IdStrings9
IdStruct
***** UNITS2.TXT
IdStrings
IdStruct
*****

***** units1.txt
JclGraphUtils
JclGraphUtils_
JclHookExcept
***** UNITS2.TXT
JclGraphUtils
JclHookExcept
*****

***** units1.txt
JvSearchFiles
JvSegmentedLEDDisplay
JvSegmentedLEDDisplayMapperFrame
JvSerialMaker
***** UNITS2.TXT
JvSearchFiles
JvSerialMaker
*****

***** units1.txt
mimepart
ModbusConsts
ModbusTypes
ModbusUtils
***** UNITS2.TXT
mimepart
ModbusUtils
*****

***** units1.txt
SynCompletionProposal
SynCrtSock
SynDBEdit
***** UNITS2.TXT
SynCompletionProposal
SynDBEdit
*****

***** units1.txt
SynURIOpener
SynWinSock
synwrap1
***** UNITS2.TXT
SynURIOpener
synwrap1
*****

***** units1.txt
uPSI_DBWeb
uPSI_DBXCharDecoder
uPSI_DBXClient
***** UNITS2.TXT
uPSI_DBWeb
uPSI_DBXClient
*****

***** units1.txt
uPSI_IdMIMETypes
uPSI_IdModBusClient
uPSI_IdModBusServer
uPSI_IdMultipartFormData
***** UNITS2.TXT
uPSI_IdMIMETypes
uPSI_IdMultipartFormData
*****

***** units1.txt
uPSI_JvSearchFiles
uPSI_JvSegmentedLEDDisplayMapperFrame
uPSI_JvSerialMaker
***** UNITS2.TXT
uPSI_JvSearchFiles
uPSI_JvSerialMaker
*****

***** units1.txt
uPSI_SynCompletionProposal
uPSI_SynCrtSock
uPSI_SynDBEdit
***** UNITS2.TXT
uPSI_SynCompletionProposal
uPSI_SynDBEdit
*****

***** units1.txt
uPSI_xrtl_util_COMUtils
uPSI_xrtl_util_CPUUtils
uPSI_xrtl_util_Exception
***** UNITS2.TXT
uPSI_xrtl_util_COMUtils
uPSI_xrtl_util_Exception
*****
1 DBXCharDecoder_
2 IdModBusClient
3 IdModBusServer
4 IdStrings9
5 JclGraphUtils_
6 JvSegmentedLEDDisplay
7 JvSegmentedLEDDisplayMapperFrame
8 ModbusConsts
9 ModbusTypes
10 SynCrtSock
11 SynWinSock
12 uPSI_DBXCharDecoder
13 uPSI_IdModBusClient
14 uPSI_IdModBusServer
15 uPSI_JvSegmentedLEDDisplayMapperFrame
16 uPSI_SynCrtSock
17 uPSI_xrtl_util_CPUUtils


Diff from 5.0.2.28 to 5.0.2.30
------------------------------------------------------------------

C:\maxbox\maxbox4\maxbox4\examples>fc 52output.txt 50output.txt
Comparing files 52Output.txt and 50OUTPUT.TXT
***** 52Output.txt
CommonTools
CompFileIo
Compilers.URunner
***** 50OUTPUT.TXT
CommonTools
Compilers.URunner
*****

***** 52Output.txt
IdIPAddress
IdIPMCastBase
IdIPMCastClient
IdIPWatch
IdLogBase
***** 50OUTPUT.TXT
IdIPAddress
IdLogBase
*****

***** 52Output.txt
IdLPR
IdMailBox
IdMappedPortUDP
***** 50OUTPUT.TXT
IdLPR
IdMappedPortUDP
*****

***** 52Output.txt
IdMessageCoderXXE
IdMessageCollection
IdMessageParts
***** 50OUTPUT.TXT
IdMessageCoderXXE
IdMessageParts
*****

***** 52Output.txt
IdQotd
IdQotdServer
IdQOTDUDP
***** 50OUTPUT.TXT
IdQotd
IdQOTDUDP
*****

***** 52Output.txt
uPSI_ComObjOleDB_utils
uPSI_CompFileIo
uPSI_CompilersURunner
***** 50OUTPUT.TXT
uPSI_ComObjOleDB_utils
uPSI_CompilersURunner
*****

***** 52Output.txt
uPSI_IdIOHandlerStream
uPSI_IdIPMCastBase
uPSI_IdIPMCastClient
uPSI_IdIPWatch
uPSI_IdLogBase
***** 50OUTPUT.TXT
uPSI_IdIOHandlerStream
uPSI_IdLogBase
*****

***** 52Output.txt
uPSI_IdLPR
uPSI_IdMailBox
uPSI_IdMappedPortUDP
***** 50OUTPUT.TXT
uPSI_IdLPR
uPSI_IdMappedPortUDP
*****

***** 52Output.txt
uPSI_IdQotd
uPSI_IdQotdServer
uPSI_IdQOTDUDP
***** 50OUTPUT.TXT
uPSI_IdQotd
uPSI_IdQOTDUDP
*****

***** 52Output.txt
uPSI_JvHtmlParser
uPSI_JvImageDrawThread
uPSI_JvImageWindow
***** 50OUTPUT.TXT
uPSI_JvHtmlParser
uPSI_JvImageWindow
*****

***** 52Output.txt
ZURL
Contains ModulesCountEnd___: 3390

***** 50OUTPUT.TXT
ZURL
Contains ModulesCountEnd___: 3376
*****


C:\maxbox\maxbox4\maxbox4\examples>

type
  TTimeZoneMode = (zmError, zmIgnore, zmAsUTC, zmAsLocal);

   TTimeZoneInfo = record
    HourOff: Integer;
    MinOff: Integer;
    HasTimeZone: Boolean;
    IsUTC: Boolean;
  end;

function AdjustTimeZone(var DateTime: TDateTime; const TimeZone: TTimeZoneInfo;
  TimeZoneMode: TTimeZoneMode): Boolean;

  function AdjustTime(Value: TDateTime; HourOff, MinOff: Integer): TDateTime;

{ Expands environment variables }
function ExpandEnv(const S: string): string;
{ Surrounds string with quotes when it contains spaces and is not quoted }
function AddQuotesUnless(const S: string): string;
{ Prepares an application name or the command line parameters for execution }
function PrepareCommandLine(S: string): string;
function WideCharsInSet( wcstr:WideString; wcset:TBits):Boolean;
function JSONUnescape(const Source: string; CRLF: string{ = #13#10}): string;
function parseJsonvalue(jsonutf8: string): string;
procedure SaveBitmapToStream(ABitmap: TBitmap; AToStream: TStream);
 function LoadBitmapFromStream(AFromStream: TStream): TBitmap;
 procedure SaveStringToStreamUTF8(AString: string; AStream: TStream);
 function LoadStringFromStreamUTF8(AStream: TStream): string;
 function LoadSubStreamFromStream(const AFromStream, AToSubStream: TStream): boolean;');
procedure SaveSubStreamToStream(const AFromSubStream, AToStream: TStream);');
function Date8ToStringRFC822(Const Date8AAfficher: string): string;
Function TextMeters(AMeters: Single; DecPlace, MaxLen, PosPoint: Byte): String;
Function RealFrmDegreeText(AText:String):double;
function TextDegreeMinuteSecondFrmDec(Value: Double; AAccuracy: Integer): String;
procedure setdebugcheck(false);
function ResolveShellLink(const Path: string): string;
function IsCOMObjectActive2(const ClassName: string): Boolean;');
function IsCOMObjectAvailable(const ClassName: string): Boolean;');
function IndyToHex(const AValue: TIdBytes): string;
function BufToBytes(var buf: string; fromindex, len: integer): TBytes;');
function BufToString_ANSI(var buf: string; fromindex, len: integer): string;');
function BufToString_UNICODE(var buf: string; fromindex, len: integer; optsourcecodepage: integer): string;');
writeln(GetFinalURL('https://maxbox4.wordpress.com/2024/04/17/post-api-image-pipeline/'));
  
function GetGeoInfoMap5save(const lat,lon, zoom: double; asize: integer;
                                    const UrlGeoLookupInfo, apath: string; showfile: boolean): string;
function GetGeoInfoMap5(const lat,lon, zoom: double; asize: integer;
                                       UrlGeoLookupInfo, apath: string; showfile: boolean): string;

ex.call:  GetGeoInfoMap5(51.22,6.77,12,850, mapboxAPIEKONKey,
                              ExePath+'examples\667_roboline_outdoor_layer5.png', true);          
  
functions TAddressGeoCodeOSM5('Hauptbahnhof, Graz, Austria'): TLatlong;
function libCompilerString: string;
function DisplayTBytes(Buf: TBytes): String;
function EncodeURIComponent2('http://www.google.com/search?q=big%25%26little')
writeln(utf8decode(EncodeURIComponent2('http://www.google.com/search?q=big%25%26little')));
  {
  alatlong:=  TAddressGeoCodeOSM5('Hauptbahnhof, Graz, Austria');
  writeln('OSM5 res back_: '+alatlong.descript);
  //writeln('get geocoords: '+flots(latlong.lat)+'   '+flots(latlong.long));  
  writeln('get geocoords: '+format(' lat: %.4f - lon: %.4f',[alatlong.lat,alatlong.long])); 
     }
procedure maxform1.console;
procedure maxform1.setconsole;
function ConvertToNegative (const Bitmap: TBitmap): TBitmap;
procedure loadjpegresource3(_instance: cardinal; aimage: Timage; aresname: string);
procedure loadjpegresource4(_instance: cardinal; aimage: Timage; aresname, restyp: string);
function loadanyresource5(_instance: cardinal; aresname, restyp: string): TResourceStream;
function loadjpegresource5(_instance: cardinal; aresname: string): Graphics.TBitmap;

procedure loadjpegresource4(_instance: cardinal; aimage: Timage; aresname, restyp: string);
var
  RS: TResourceStream;
  JPGImage: TJPEGImage;
begin
  JPGImage := TJPEGImage.Create;
  //result:= Timage.Create(nil);
  try
    RS := TResourceStream.Create(_Instance, aresname, pwidechar(restyp));
    try
      JPGImage.LoadFromStream(RS);
      aimage.Picture.Graphic := JPGImage;
    finally
      RS.Free;
    end;
  finally
    JPGImage.Free;
  end;
end;


procedure saveasunicode; //v5.02.60
begin
    //to save contexr as unicode - append(Text(mycodestring))
    maxform1.memo1.lines.savetofile(maxform1.Act_Filename, TEncoding.UTF8);
    maxform1.memo2.lines.Add('----File saved as Unicode!----UTF8 😀');
    maxform1.memo1.Lines.LoadFromFile(maxform1.Act_Filename, TEncoding.UTF8);
end;

procedure saveasansi; //v5.02.60
begin
    //to save contexr as unicode - append(Text(mycodestring))
    maxform1.memo1.lines.savetofile(maxform1.Act_Filename, TEncoding.ansi);
    maxform1.memo2.lines.Add('----File saved as Ansi!----Ansi8');
end;

V.0.2.70

uPSI_flcUnicodeCodecs
procedure SIRegister_flcUnicodeCodecs(CL: TPSPascalCompiler);
begin
  CL.AddTypeS('TCodecErrorAction', '( eaException, eaStop, eaIgnore, eaSkip, eaReplace )');
  CL.AddTypeS('TCodecReadLFOption', '( lrPass, lrNormalize )');
  CL.AddTypeS('TCodecWriteLFOption', '( lwLF, lwCR, lwCRLF )');
  CL.AddTypeS('ByteChar','AnsiChar');
  CL.AddTypeS('TCodecReadEvent', 'Procedure ( Sender : TObject; var Buf, Count '
   +': Longint; var Ok : Boolean)');
  CL.AddTypeS('TCodecWriteEvent', 'Procedure ( Sender : TObject; const Buf, Count : Longint)');
  SIRegister_TCustomUnicodeCodec(CL);
  //&&&&&&CL.AddTypeS('TUnicodeCodecClass', 'class of TCustomUnicodeCodec');
  CL.AddTypeS('TUnicodeCodecClass', 'TCustomUnicodeCodec');
  SIRegister_EUnicodeCodecException(CL);
 CL.AddDelphiFunction('Procedure RegisterCodecs( const Codecs : array of TUnicodeCodecClass)');
 CL.AddDelphiFunction('Function GetCodecClassByAlias( const CodecAlias : String) : TUnicodeCodecClass');
 CL.AddDelphiFunction('Function GetCodecClassByAliasA( const CodecAlias : RawByteString) : TUnicodeCodecClass');
 CL.AddDelphiFunction('Function GetCodecClassByAliasU( const CodecAlias : UnicodeString) : TUnicodeCodecClass');
 CL.AddDelphiFunction('Function GetSystemEncodingName : String');
 CL.AddDelphiFunction('Function GetSystemEncodingCodecClass : TUnicodeCodecClass');
 CL.AddDelphiFunction('Function DetectUTFEncoding(const Buf: __Pointer; const BufSize:Integer;out BOMSize : Integer): TUnicodeCodecClass');
 CL.AddDelphiFunction('Function EncodingToUTF16U(const CodecClass : TUnicodeCodecClass; const Buf : __Pointer; const BufSize : Integer) : UnicodeString;');
 CL.AddDelphiFunction('Function EncodingToUTF16U1(const CodecClass : TUnicodeCodecClass; const S : RawByteString) : UnicodeString;');
 CL.AddDelphiFunction('Function EncodingToUTF16U2(const CodecAlias : String; const Buf : __Pointer; const BufSize : Integer) : UnicodeString;');
 CL.AddDelphiFunction('Function EncodingToUTF16U3(const CodecAlias:String;const S:RawByteString):UnicodeString;');
 CL.AddDelphiFunction('Function UTF16ToEncodingU( const CodecClass : TUnicodeCodecClass; const S : UnicodeString) : RawByteString;');
 CL.AddDelphiFunction('Function UTF16ToEncodingU1(const CodecAlias:String;const S:UnicodeString):RawByteString;');
  SIRegister_TUTF8Codec(CL);
  SIRegister_TUTF16LECodec(CL);
  SIRegister_TUTF16BECodec(CL);
  SIRegister_TUCS4BECodec(CL);
  SIRegister_TUCS4LECodec(CL);
  SIRegister_TUCS4_2143Codec(CL);
  SIRegister_TUCS4_3412Codec(CL);
  SIRegister_TUCS2Codec(CL);
  SIRegister_TCustomSingleByteCodec(CL);
  //CL.AddTypeS('TUnicodeSingleByteCodecClass', 'class of TCustomSingleByteCodec');
  SIRegister_TISO8859_1Codec(CL);
  SIRegister_TISO8859_2Codec(CL);
  SIRegister_TISO8859_3Codec(CL);
  SIRegister_TISO8859_4Codec(CL);
  SIRegister_TISO8859_5Codec(CL);
  SIRegister_TISO8859_6Codec(CL);
  SIRegister_TISO8859_7Codec(CL);
  SIRegister_TISO8859_8Codec(CL);
  SIRegister_TISO8859_9Codec(CL);
  SIRegister_TISO8859_10Codec(CL);
  SIRegister_TISO8859_13Codec(CL);
  SIRegister_TISO8859_14Codec(CL);
  SIRegister_TISO8859_15Codec(CL);
  SIRegister_TWindows37Codec(CL);
  SIRegister_TWindows437Codec(CL);
  SIRegister_TWindows500Codec(CL);
  SIRegister_TWindows708Codec(CL);
  SIRegister_TWindows737Codec(CL);
  SIRegister_TWindows775Codec(CL);
  SIRegister_TWindows850Codec(CL);
  SIRegister_TWindows852Codec(CL);
  SIRegister_TWindows855Codec(CL);
  SIRegister_TWindows857Codec(CL);
  SIRegister_TWindows858Codec(CL);
  SIRegister_TWindows861Codec(CL);
  SIRegister_TWindows862Codec(CL);
  SIRegister_TWindows863Codec(CL);
  SIRegister_TWindows864Codec(CL);
  SIRegister_TWindows865Codec(CL);
  SIRegister_TWindows866Codec(CL);
  SIRegister_TWindows869Codec(CL);
  SIRegister_TWindows870Codec(CL);
  SIRegister_TWindows874Codec(CL);
  SIRegister_TWindows875Codec(CL);
  SIRegister_TWindows1026Codec(CL);
  SIRegister_TWindows1047Codec(CL);
  SIRegister_TWindows1140Codec(CL);
  SIRegister_TWindows1141Codec(CL);
  SIRegister_TWindows1142Codec(CL);
  SIRegister_TWindows1143Codec(CL);
  SIRegister_TWindows1144Codec(CL);
  SIRegister_TWindows1145Codec(CL);
  SIRegister_TWindows1146Codec(CL);
  SIRegister_TWindows1147Codec(CL);
  SIRegister_TWindows1148Codec(CL);
  SIRegister_TWindows1149Codec(CL);
  SIRegister_TWindows1250Codec(CL);
  SIRegister_TWindows1251Codec(CL);
  SIRegister_TWindows1252Codec(CL);
  SIRegister_TWindows1253Codec(CL);
  SIRegister_TWindows1254Codec(CL);
  SIRegister_TWindows1255Codec(CL);
  SIRegister_TWindows1256Codec(CL);
  SIRegister_TWindows1257Codec(CL);
  SIRegister_TWindows1258Codec(CL);
  SIRegister_TIBM037Codec(CL);
  SIRegister_TIBM038Codec(CL);
  SIRegister_TIBM256Codec(CL);
  SIRegister_TIBM273Codec(CL);
  SIRegister_TIBM274Codec(CL);
  SIRegister_TIBM275Codec(CL);
  SIRegister_TIBM277Codec(CL);
  SIRegister_TIBM278Codec(CL);
  SIRegister_TIBM280Codec(CL);
  SIRegister_TIBM281Codec(CL);
  SIRegister_TIBM284Codec(CL);
  SIRegister_TIBM285Codec(CL);
  SIRegister_TIBM290Codec(CL);
  SIRegister_TIBM297Codec(CL);
  SIRegister_TIBM420Codec(CL);
  SIRegister_TIBM423Codec(CL);
  SIRegister_TIBM424Codec(CL);
  SIRegister_TIBM437Codec(CL);
  SIRegister_TIBM500Codec(CL);
  SIRegister_TIBM850Codec(CL);
  SIRegister_TIBM851Codec(CL);
  SIRegister_TIBM852Codec(CL);
  SIRegister_TIBM855Codec(CL);
  SIRegister_TIBM857Codec(CL);
  SIRegister_TIBM860Codec(CL);
  SIRegister_TIBM861Codec(CL);
  SIRegister_TIBM862Codec(CL);
  SIRegister_TIBM863Codec(CL);
  SIRegister_TIBM864Codec(CL);
  SIRegister_TIBM865Codec(CL);
  SIRegister_TIBM866Codec(CL);
  SIRegister_TIBM868Codec(CL);
  SIRegister_TIBM869Codec(CL);
  SIRegister_TIBM870Codec(CL);
  SIRegister_TIBM871Codec(CL);
  SIRegister_TIBM874Codec(CL);
  SIRegister_TIBM875Codec(CL);
  SIRegister_TIBM880Codec(CL);
  SIRegister_TIBM904Codec(CL);
  SIRegister_TIBM905Codec(CL);
  SIRegister_TIBM918Codec(CL);
  SIRegister_TIBM1004Codec(CL);
  SIRegister_TIBM1026Codec(CL);
  SIRegister_TIBM1047Codec(CL);
  SIRegister_TMacLatin2Codec(CL);
  SIRegister_TMacRomanCodec(CL);
  SIRegister_TMacCyrillicCodec(CL);
  SIRegister_TMacGreekCodec(CL);
  SIRegister_TMacIcelandicCodec(CL);
  SIRegister_TMacTurkishCodec(CL);
  SIRegister_TUSASCIICodec(CL);
  SIRegister_TEBCDIC_USCodec(CL);
  SIRegister_TKOI8_RCodec(CL);
  SIRegister_TJIS_X0201Codec(CL);
  SIRegister_TNextStepCodec(CL);
  CL.AddDelphiFunction('Procedure UnicodeCodecTest');
  CL.AddDelphiFunction('Procedure TestUnicodeCodecs');
end;

  {  Procedure PostMultipartFormData(const aUrl:AnsiString;
                                    const aRequestFields: TALStrings;
                                    const aRequestFiles: TALMultiPartFormDataContents;
                                    const aResponseContent: TStream;
                                    const aResponseHeader: TALHTTPResponseHeader2;
                                    const ARequestHeaderValues: TALNameValueArray = nil); overload;
       }

 LParamToSend: TIdMultiPartFormDataStream;   
  FHttp: TIDHTTP;   idformdaf: TIdFormDataField;
   

Doc:   https://www.fileformat.info/info/unicode/char/262e/index.htm

CL.AddDelphiFunction('function GetElementAtIndex(S: String; StrIdx : Integer): String;');
CL.AddDelphiFunction('function NormalizeText(Str: string): string; ');
function GetFirstCodepointSize(const S: UTF8String): Integer;
function Utf8ToUtf16( const sIn: AnsiString; iSrcCodePage: DWord): WideString;
procedure SaveString2(const AFile, AText: string);
procedure SaveString3(const AFile, AText: string; Append: Boolean);  //UTF8

function LoadFile3(const FileName: TFileName): string;
  var Stri: TStrings;  Stream: TStream;
   begin
     stream:=  TFileStream.Create(FileName, fmOpenRead or fmShareDenyWrite);
      Stri:= TStringlist.create;
      try
       try
         stri.LoadFromStream(Stream, TEncoding.UTF8);
         result:= stri.Text;
       except
         Result := '';  // Deallocates memory
         stream.Free;
         raise;
       end;
      finally
        stri.Free;
        stream.Free;
      end;
   end;

http://www.softwareschule.ch/download/maxbox_starter60_1.pdf

constructor TStreamWriter.Create(const Filename: string; Append: Boolean);
begin
  if not Append or not FileExists(Filename) then
    FStream := TFileStream.Create(Filename, fmCreate)
  else
  begin
    FStream := TFileStream.Create(Filename, fmOpenWrite);
    FStream.Seek(0, soEnd);
  end;
  Create(FStream);
  FOwnsStream := True;
end;

constructor TStreamWriter.Create(const Filename: string; Append: Boolean;
  Encoding: TEncoding; BufferSize: Integer);
begin
  if not Append or not FileExists(Filename) then
    FStream := TFileStream.Create(Filename, fmCreate)
  else
  begin
    FStream := TFileStream.Create(Filename, fmOpenWrite);
    FStream.Seek(0, soEnd);
  end;
  Create(FStream, Encoding, BufferSize);
  FOwnsStream := True;
end;


procedure SaveString3(const AFile, AText: string; Append: Boolean);
var
  Writer: TStreamWriter;   //, TEncoding.UTF8
begin
 //GetElementAtIndex
  { Create a new stream writer directly. }
  Writer := TStreamWriter.Create(Afile, append, TEncoding.UTF8);
  try
    Writer.Write(Atext);
  finally
  { Close and free the writer. }
    Writer.Free;
  end;
end;

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 8CF17E0D7519771801217DD3FD339F5E222DEB19E4FFC94667DB1E6C83A7913D

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Jan 04 12:42:33 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

V5.0.2.80          Recode Tech

procedure SIRegister_RegularExpressions(CL: TPSPascalCompiler);
begin
  CL.AddTypeS('TRegExOption', '( rroNone, rroIgnoreCase, rroMultiLine, rroExplicitC'
   +'apture, rroCompiled, rroSingleLine, rroIgnorePatternSpace, rroNotEmpty )');
  CL.AddTypeS('TRegExOptions', 'set of TRegExOption');
  SIRegister_TGroup(CL);
  CL.AddClassN(CL.FindClass('TOBJECT'),'TGroupCollectionEnumerator');
  SIRegister_TGroupCollection(CL);
  SIRegister_TGroupCollectionEnumerator(CL);
  SIRegister_TMatch(CL);
  CL.AddClassN(CL.FindClass('TOBJECT'),'TMatchCollectionEnumerator');
  SIRegister_TMatchCollection(CL);
  SIRegister_TMatchCollectionEnumerator(CL);
  CL.AddTypeS('TMatchEvaluator', 'Function ( const Match : TMatch) : string');
  SIRegister_TRegEx(CL);
end;

with CL.AddClassN(CL.FindClass('TOBJECT'),'TRegEx') do
  begin
    RegisterMethod('Constructor Create( const Pattern : string; Options : TRegExOptions)');
    RegisterMethod('Constructor Create1( const Pattern : string)');

    RegisterMethod('Function IsMatch( const Input : string) : Boolean;');
    RegisterMethod('Function IsMatch1( const Input : string; StartPos : Integer) : Boolean;');
    RegisterMethod('Function IsMatch2( const Input, Pattern : string) : Boolean;');
    RegisterMethod('Function IsMatch3( const Input, Pattern : string; Options : TRegExOptions) : Boolean;');
    RegisterMethod('Function Escape( const Str : string; UseWildCards : Boolean) : string');
    RegisterMethod('Function Match( const Input : string) : TMatch;');
    RegisterMethod('Function Match1( const Input : string; StartPos : Integer) : TMatch;');
    RegisterMethod('Function Match2( const Input : string; StartPos, Length : Integer) : TMatch;');
    RegisterMethod('Function Match3( const Input, Pattern : string) : TMatch;');
    RegisterMethod('Function Match4( const Input, Pattern : string; Options : TRegExOptions) : TMatch;');
    RegisterMethod('Function Matches( const Input : string) : TMatchCollection;');
    RegisterMethod('Function Matches1( const Input : string; StartPos : Integer) : TMatchCollection;');
    RegisterMethod('Function Matches2( const Input, Pattern : string) : TMatchCollection;');
    RegisterMethod('Function Matches3(const Input,Pattern string; Options:TRegExOptions) : TMatchCollection;');
    RegisterMethod('Function Replace( const Input, Replacement : string) : string;');
    RegisterMethod('Function Replace1( const Input : string; Evaluator : TMatchEvaluator) : string;');
    RegisterMethod('Function Replace2( const Input, Replacement : string; Count : Integer) : string;');
    RegisterMethod('Function Replace3(const Input:string;Evaluator:TMatchEvaluator; Count : Integer) : string;');
    RegisterMethod('Function Replace4( const Input, Pattern, Replacement : string) : string;');
    RegisterMethod('Function Replace5( const Input, Pattern : string; Evaluator : TMatchEvaluator) : string;');
    RegisterMethod('Function Replace6(const Input,Pattern,Replacement:string;Options:TRegExOptions) : string;');
    RegisterMethod('Function Replace7( const Input, Pattern : string; Evaluator : TMatchEvaluator; Options : TRegExOptions) : string;');
  end;
end;

function TBytesMerge(arr1, arr2: TBytes): TBytes;
var
  ofs: integer;
begin
  setlength(result, length(arr1) + length(arr2));
  ofs := 0;
  if length(arr1)>0 then
  begin
    Move(arr1[0], result[ofs], length(arr1));
    inc(ofs, length(arr1));
  end;
  if length(arr2)>0 then
  begin
    Move(arr2[0], result[ofs], length(arr2));
    inc(ofs, length(arr2));
  end;
end;

function parsejsonvalue2(JsonUTF8: string): string;
var
  LJSONValue: TJSONValue;
begin
 
   { convert String to JSON }
   LJSONValue:=TJSONObject.ParseJSONValue(TEncoding.UTF8.GetBytes(JsonUtf8),0);
    result:= LJSONValue.ToString;
end;

function Exit3(exitcode: integer): integer;
begin
   system.exit(exitcode);
end;

function StringToBytes_Encode(const s: string; destcodepage: integer; withBOM: boolean = true): TBytes;
function BytesToString_Decode(arr: TBytes; optsourcecodepage: integer = 0): string;
CL.AddDelphiFunction('Function SystemCodePage : Integer');
 CL.AddDelphiFunction('Function GetCodePage : Integer');
procedure BurrowsWheeler
procedure testUnicode(typ: byte);
const
  SMILEY_UTF8_SLIGHTLY_SMILING_FACE: TBytes = [$E2, $98, $BA]; // Unicode Code Point: U+263A
begin
  if typ = 1  then
     ShowMessage('hi unicode '+TEncoding.UTF8.GetString(SMILEY_UTF8_SLIGHTLY_SMILING_FACE));
  if typ= 2  then
    maxform1.memo2.lines.add(TEncoding.UTF8.GetString(SMILEY_UTF8_SLIGHTLY_SMILING_FACE));
  if typ= 3  then
    maxform1.caption:= maxform1.Caption +(TEncoding.UTF8.GetString(SMILEY_UTF8_SLIGHTLY_SMILING_FACE));
end;

procedure SIRegister_TIdIOHandler(CL: TPSPascalCompiler);
begin
  //with RegClassS(CL,'TIdComponent', 'TIdIOHandler') do
  with CL.AddClassN(CL.FindClass('TIdComponent'),'TIdIOHandler') do begin
    RegisterMethod('Constructor Create( AOwner : TComponent)');
    RegisterMethod('Procedure Free;');
    RegisterMethod('Procedure AfterAccept');
    RegisterMethod('Function Connected : Boolean');
    RegisterMethod('Procedure CheckForDisconnect(ARaiseExceptionIfDisconnected:Boolean;AIgnoreBuffer:Boolean)');
    RegisterMethod('Function CheckForDataOnSource( ATimeout : Integer) : Boolean');
    RegisterMethod('Procedure Close');
    RegisterMethod('Procedure CloseGracefully');
    RegisterMethod('Function MakeDefaultIOHandler( AOwner : TComponent) : TIdIOHandler');
    RegisterMethod('Function MakeIOHandler( ABaseType: TIdIOHandlerClass; AOwner : TComponent) : TIdIOHandler');
    RegisterMethod('Function TryMakeIOHandler(ABaseType:TIdIOHandlerClass; AOwner:TComponent):TIdIOHandler');
    RegisterMethod('Procedure RegisterIOHandler');
    RegisterMethod('Procedure SetDefaultClass');
    RegisterMethod('Function WaitFor const AString: string; ARemoveFromBuffer:Boolean; AInclusive:Boolean; AByteEncoding: IIdTextEncoding; ATimeout : Integer; AAnsiEncoding : IIdTextEncoding) : string');
    RegisterMethod('Procedure Write(const ABuffer: TIdBytes;const ALength : Integer; const AOffset : Integer);');
    RegisterMethod('Procedure WriteDirect(const ABuffer:TIdBytes; const ALength:Integer;const AOffset:Integer)');
    RegisterMethod('Procedure Open');
    RegisterMethod('Function Readable( AMSec : Integer) : Boolean');
    RegisterMethod('Procedure Write1(const AOut:string;AByteEncoding:IIdTextEncoding;ASrcEncoding: IIdTextEncoding);');
    RegisterMethod('Procedure WriteLn2( AEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure WriteLn3(const AOut:string;AByteEncoding:IIdTextEncoding;ASrcEncoding: IIdTextEncoding);');
  RegisterMethod('Procedure WriteLn1( const AOut : string);');

    RegisterMethod('Procedure WriteLnRFC(const AOut:string;AByteEncoding:IIdTextEncoding;ASrcEncoding : IIdTextEncoding)');
    RegisterMethod('Procedure Write4( AValue : TStrings; AWriteLinesCount : Boolean; AByteEncoding : IIdTextEncoding; ASrcEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure Write5( AValue : Byte);');
    RegisterMethod('Procedure Write6(AValue:Char;AByteEncoding:IIdTextEncoding;ASrcEncoding: IIdTextEncoding);');
    RegisterMethod('Procedure Write7( AValue : Int16; AConvert : Boolean);');
    RegisterMethod('Procedure Write8( AValue : UInt16; AConvert : Boolean);');
    RegisterMethod('Procedure Write9( AValue : Int32; AConvert : Boolean);');
    RegisterMethod('Procedure Write10( AValue : UInt32; AConvert : Boolean);');
    RegisterMethod('Procedure Write11( AValue : Int64; AConvert : Boolean);');
    RegisterMethod('Procedure Write12( AValue : TIdUInt64; AConvert : Boolean);');
    RegisterMethod('Procedure Write13( AStream : TStream; ASize : TIdStreamSize; AWriteByteCount : Boolean);');
RegisterMethod('Procedure WriteStream( AStream : TStream; ASize : TIdStreamSize; AWriteByteCount : Boolean);');
    RegisterMethod('Procedure WriteStream2(AStream:TStream; ASize: TIdStreamSize;AWriteByteCount : Boolean);');

    RegisterMethod('Procedure WriteRFCStrings( AStrings : TStrings; AWriteTerminator : Boolean; AByteEncoding : IIdTextEncoding; ASrcEncoding : IIdTextEncoding)');
    RegisterMethod('Function WriteFile( const AFile : String; AEnableTransferFile : Boolean) : Int64');
    RegisterMethod('Function AllData( AByteEncoding:IIdTextEncoding; ADestEncoding : IIdTextEncoding) : string');
    RegisterMethod('Function InputLn( const AMask : string; AEcho : Boolean; ATabWidth : Integer; AMaxLineLength : Integer; AByteEncoding : IIdTextEncoding; AAnsiEncoding : IIdTextEncoding) : string');
    RegisterMethod('Procedure Capture14(ADest:TStream;AByteEncoding:IIdTextEncoding;ADestEncoding: IIdTextEncoding);');
    RegisterMethod('Procedure Capture15( ADest : TStream; ADelim : string; AUsesDotTransparency : Boolean; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure Capture16( ADest : TStream; out VLineCount : Integer; const ADelim : string; AUsesDotTransparency : Boolean; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure Capture17(ADest:TStrings;AByteEncoding:IIdTextEncoding;ADestEncoding: IIdTextEncoding);');
    RegisterMethod('Procedure Capture18( ADest : TStrings; const ADelim : string; AUsesDotTransparency : Boolean; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure Capture19( ADest : TStrings; out VLineCount : Integer; const ADelim : string; AUsesDotTransparency : Boolean; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding);');
    RegisterMethod('Procedure ReadBytes( var VBuffer : TIdBytes; AByteCount : Integer; AAppend : Boolean)');
    RegisterMethod('Function ReadLn( AByteEncoding: IIdTextEncoding; ADestEncoding: IIdTextEncoding) : string;');
RegisterMethod('Function ReadLn1: string;');
    RegisterMethod('Function ReadLn21( ATerminator : string; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding) : string;');
    RegisterMethod('Function ReadLn22( ATerminator : string; ATimeout : Integer; AMaxLineLength : Integer; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding) : string;');
    RegisterMethod('Function ReadLnRFC23(var VMsgEnd:Boolean; AByteEncoding:IIdTextEncoding;ADestEncoding : IIdTextEncoding) : string;');
    RegisterMethod('Function ReadLnRFC24( var VMsgEnd : Boolean; const ALineTerminator : string; const ADelim : string; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding) : string;');
    RegisterMethod('Function ReadLnWait( AFailCount:Integer;AByteEncoding:IIdTextEncoding;ADestEncoding: IIdTextEncoding):string');
    RegisterMethod('Function ReadLnSplit( var AWasSplit : Boolean; ATerminator : string; ATimeout : Integer; AMaxLineLength : Integer; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding) : string');
    RegisterMethod('Function ReadChar( AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding) : Char');
    RegisterMethod('Function ReadByte : Byte');
    RegisterMethod('Function ReadString(ABytes: Integer;AByteEncoding:IIdTextEncoding;ADestEncoding : IIdTextEncoding):string');
    RegisterMethod('Function ReadInt16( AConvert : Boolean) : Int16');
    RegisterMethod('Function ReadUInt16( AConvert : Boolean) : UInt16');
    RegisterMethod('Function ReadInt32( AConvert : Boolean) : Int32');
    RegisterMethod('Function ReadUInt32( AConvert : Boolean) : UInt32');
    RegisterMethod('Function ReadInt64( AConvert : Boolean) : Int64');
    RegisterMethod('Function ReadUInt64( AConvert : Boolean) : TIdUInt64');
    RegisterMethod('Procedure ReadStream(AStream:TStream;AByteCount:TIdStreamSize;AReadUntilDisconnect: Boolean);
    RegisterMethod('Procedure ReadStrings( ADest : TStrings; AReadLinesCount : Integer; AByteEncoding : IIdTextEncoding; ADestEncoding : IIdTextEncoding)');
    RegisterMethod('Procedure Discard( AByteCount : Int64)');
    RegisterMethod('Procedure DiscardAll');
    RegisterMethod('Procedure WriteBufferCancel');
    RegisterMethod('Procedure WriteBufferClear');
    RegisterMethod('Procedure WriteBufferClose');
    RegisterMethod('Procedure WriteBufferFlush25;');
    RegisterMethod('Procedure WriteBufferFlush26( AByteCount : Integer);');
    RegisterMethod('Procedure WriteBufferOpen27;');
    RegisterMethod('Procedure WriteBufferOpen28( AThreshold : Integer);');
    RegisterMethod('Function WriteBufferingActive : Boolean');
    RegisterMethod('Function InputBufferIsEmpty : Boolean');
    RegisterMethod('Procedure InputBufferToStream( AStream : TStream; AByteCount : Integer)');
    RegisterMethod('Function InputBufferAsString( AByteEncoding: IIdTextEncoding;ADestEncoding:IIdTextEncoding): string');
    RegisterProperty('ConnectTimeout', 'Integer', iptrw);
    RegisterProperty('ClosedGracefully', 'Boolean', iptr);
    RegisterProperty('InputBuffer', 'TIdBuffer', iptr);
    RegisterProperty('LargeStream', 'Boolean', iptrw);
    RegisterProperty('MaxCapturedLines', 'Integer', iptrw);
    RegisterProperty('Opened', 'Boolean', iptr);
    RegisterProperty('ReadTimeout', 'Integer', iptrw);
    RegisterProperty('ReadLnTimedout', 'Boolean', iptr);
    RegisterProperty('WriteBufferThreshold', 'Integer', iptr);
    RegisterProperty('DefStringEncoding', 'IIdTextEncoding', iptrw);
    RegisterProperty('DefAnsiEncoding', 'IIdTextEncoding', iptrw);
    RegisterProperty('Destination', 'string', iptrw);
    RegisterProperty('Host', 'string', iptrw);
    RegisterProperty('Intercept', 'TIdConnectionIntercept', iptrw);
    RegisterProperty('MaxLineLength', 'Integer', iptrw);
    RegisterProperty('MaxLineAction', 'TIdMaxLineAction', iptrw);
    RegisterProperty('Port', 'Integer', iptrw);
    RegisterProperty('RecvBufferSize', 'Integer', iptrw);
    RegisterProperty('SendBufferSize', 'Integer', iptrw);
  end;
end;

function PointsAdd(const A, B: TPoint): TPoint;
function PointsDec(const A, B: TPoint): TPoint;
function PointsAbs(const P: TPoint): TPoint;



Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 5FFFCCDAC0A0E1D6E142F8825BD1DFF1E16A5C71F1BBEA17FD926BCF255D9E31

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Wed Jan 17 12:02:12 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 69E63032FCFC5CC3B8F99C1549D8F220680B10B67468FE906568D22111501C7E

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Jan 26 13:45:38 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): F2F10CF05229735E4A22538B1634CC90AE23AF4EEAFDAFAB749E7D84718C7116

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Jan 26 21:18:13 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 2164D7CFD4D4AC8A30960EF5DD033B871BDE9136AA3C8AF9A656E6CA0822B464

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Jan 28 20:04:53 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 621EEB523ABA49E248D624F4DC59ACFB331142818BBBC80F6E1C07C931BF6030

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Feb 01 13:25:23 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 963F55F4A882BC556BBEB18A41DFC859B7D34745BA94FF25611F5C8E5FD47940

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Feb 04 21:22:38 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

502 UNICODE Test
maXbox Version Check File

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 479B45D4FCFFB1DE46B05F1A6848DFA39456DB3A3DA887EC22381C2D0071C28D

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Mon Feb 12 13:55:55 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 2AE50D60BF9FF5ACB11AC66F6F43DF35A9E9F58262626D6748F82950A722CA76

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Feb 15 11:50:07 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): C56226F60CABD03C55B419B8743646A992284A40FC25C9D5B1CCF651782F91E6

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Feb 16 20:45:20 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): E9624C37690A21765B6AC006B408294D336F1B17CD9ACB36FAC6789517ABB959

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Feb 18 15:20:04 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 3B8B55ECA0451796D5209D8E3390006C87C9D59F36840C6B9E33B9BB6606F723

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sat Feb 24 16:02:15 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): CD6C8BB37F8D06425107871E6C072E57974D2ED4D1FC48FC83E6E9517DEEE405

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Feb 25 17:51:02 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): AE01859E2DD1B4747F8B27AF7F6A8C489B9068B68C2FB2B0C02F7FCBE7D0C970

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Mar 01 14:15:10 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 2BA3FC897177C0BD31FF85ECF37878F8E72D5B187004A875FD2397B3E944C627

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Mar 03 13:16:41 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): B0A191126ABDAA2CFC338449B19A348F05286BCEAB52ADDFECE13177E5C2097B

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Mar 03 15:38:51 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 960253943271DF2AA7DD0369C1DC4F8B11DF0704E2AE523A3930EC4C6EE160E1

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Mar 07 18:12:18 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0


(*----------------------------------------------------------------------------*)
procedure SIRegister_RNavigateLongLat(CL: TPSPascalCompiler);
begin
  //with RegClassS(CL,'TOBJECT', 'RNavigateLongLat') do
  with CL.AddClassN(CL.FindClass('TOBJECT'),'RNavigateLongLat') do begin
    RegisterMethod('Procedure GoGoogle');
    RegisterMethod('Procedure GoGoogleDirectionsTo( ADestination : RNavigateLongLat; AMapLoc : Integer)');
    RegisterMethod('Procedure SetToNull');
    RegisterMethod('Procedure CreateDec( ADecLong, ADecLatt : Double)');
    RegisterMethod('Procedure Create( ALongRad, ALatRad : Double)');
    RegisterMethod('Procedure GoogleScaleByMeters( AMeters : Double)');
    RegisterMethod('Function LocatationText( ASecDecPlaces : Integer) : String');
    RegisterMethod('Function LocatationCsv( ADecPlaces : Integer) : String');
    RegisterMethod('Function LongitudeText( ASecDecPlaces : Integer) : String');
    RegisterMethod('Function LatitudeText( ASecDecPlaces : Integer) : String');
    RegisterMethod('Function MetresFrom( AStart : RNavigateLongLat) : Double');
    RegisterMethod('Function MetresFromPrecision( AStart : RNavigateLongLat; out ARadiansToStart, ARadiansFromStart : Double; AAllowPolarRoute : Boolean) : Double');
    RegisterMethod('Function LocationAtMtrsRad( AMeters, ATrueHeadingRadians : Double) : RNavigateLongLat');
    RegisterMethod('Function LocationAt( AMeters, ATrueHeadingDegrees : Double) : RNavigateLongLat');
    RegisterMethod('Function HeadingFrom( AStart : RNavigateLongLat) : Double');
    RegisterMethod('Function HeadingInRadFrom( AStart : RNavigateLongLat) : Double');
    RegisterMethod('Function GoogleLink : String');
    RegisterMethod('Function GoogleLinkDirectionsTo(ADestination:RNavigateLongLat; AMapLoc: Integer) : String');
    RegisterMethod('Function IsValid : Boolean');
    RegisterMethod('Function NotNull : Boolean');
    RegisterMethod('Function HeadingFromAsText( AStart : RNavigateLongLat; ADecPlace : Integer) : String');
    RegisterProperty('Longitude', 'Double', iptrw);
    RegisterProperty('Latitude', 'Double', iptrw);
    RegisterProperty('LongAsRad', 'Double', iptr);
    RegisterProperty('LatAsRad', 'Double', iptr);
    RegisterProperty('GoogleScale', 'Integer', iptrw);
  end;
end;

(*----------------------------------------------------------------------------*)
procedure SIRegister_IsNavUtils2(CL: TPSPascalCompiler);
begin
  SIRegister_RNavigateLongLat(CL);
 CL.AddDelphiFunction('Function TextMeters2( AMeters : Single; DecPlace, MaxLen, PosPoint : Byte) : String');
 CL.AddDelphiFunction('Function AngleDecFrmDegreeMinuteSecond(ADegrees,AMinutes:Integer;ASeconds:Double): Double;');
 CL.AddDelphiFunction('Function TextDegreeMinuteSecond( ARadians : Double; AAccuracy : Integer) : String;');
 CL.AddDelphiFunction('Function TextDegreeMinuteSecondFrmDec2( Value : Double; AAccuracy : Integer) : String');
 CL.AddDelphiFunction('Procedure CalNewDoubleAverageAndSumOfSquares( ANewSample : Double; var ARunningAveage, ARunningAveageSumOfSqrs : Double; ANoOfSamples : Integer)');
 CL.AddDelphiFunction('Procedure CalNewRationalAngleDegreesAverageAndSumOfSquares( ANewSample : Double; var ARunningAngleAve, RunningAngleSumOfSquares : Double; ANoOfSamples : Integer; AReturn0to360 : Boolean)');
 CL.AddDelphiFunction('Procedure CalNewRationalAngleRadiansAverageAndSumOfSquares( ANewSample : Double; var RunningAngleSumOfSquares, ARunningAngleAve : Double; ANoOfSamples : Integer)');
 CL.AddDelphiFunction('Function CalDoubleStdDevFromSumOfSquares(ARunningAveageSumOfSqrs Double; ANoOfSamples : Integer): Double');
 CL.AddDelphiFunction('Function MtrsPerDegreeLongAdjustForLatitude( ALatitudeDegree : Double) : Double');
 CL.AddDelphiFunction('Function RealFrmDegreeText2( AText : String) : double');
 CL.AddConstantN('EarthRad','Double').setExtended( 6371008.8);
 CL.AddConstantN('MtrsPerDegree','Double').setExtended( Pi * 6371008.8 / 180);
 CL.AddConstantN('AngleDegreeChar','String').SetString( '°');
 CL.AddConstantN('AngleMins','String').SetString( '''');
 CL.AddConstantN('AngleSecs','String').SetString( '"');
 CL.AddConstantN('EffectiveZero','Extended').setExtended( 0.0000000001);
end;

procedure SIRegister_TAChartUtils(CL: TPSPascalCompiler);
begin
 CL.AddConstantN('CHART_COMPONENT_IDE_PAGE','String').SetString( 'Chart');
 CL.AddConstantN('taPERCENT','Extended').setExtended( 0.01);
 CL.AddConstantN('clTAColor','LongWord').SetUInt( $20000000);
 CL.AddConstantN('DEFAULT_FONT_SIZE','LongInt').SetInt( 10);
  CL.AddClassN(CL.FindClass('TOBJECT'),'EChartError');
  CL.AddClassN(CL.FindClass('TOBJECT'),'EChartIntervalError');
  CL.AddClassN(CL.FindClass('TOBJECT'),'EListenerError');
  CL.AddClassN(CL.FindClass('TOBJECT'),'EDrawDataError');
  CL.AddTypeS('TDoublePoint', 'record X : Double; Y : Double; end');
  CL.AddTypeS('TATPointArray', 'array of TPoint');
  CL.AddTypeS('TDoublePointArray', 'array of TDoublepoint');
  CL.AddTypeS('TChartDistance', 'Integer');
  CL.AddTypeS('TATPercent', 'Integer');
  CL.AddTypeS('TTransformFunc', 'Function ( A : Double) : Double');
  CL.AddTypeS('TImageToGraphFunc', 'Function ( AX : Integer) : Double');
  CL.AddTypeS('TGraphToImageFunc', 'Function ( AX : Double) : Integer');
  CL.AddTypeS('TChartUnits', '( cuPercent, cuAxis, cuGraph, cuPixel )');
  CL.AddTypeS('TOverrideColor', '( ocBrush, ocPen )');
  CL.AddTypeS('TOverrideColors', 'set of TOverrideColor');
 // CL.AddTypeS('TSeriesMarksStyle', '( smsCustom, smsNone, smsValue, smsPercent,'
 //  +' smsLabel, smsLabelPercent, smsLabelValue, smsLegend, smsPercentTotal, sms'
 //  +'LabelPercentTotal, smsXValue )');
  CL.AddTypeS('TDoubleInterval', 'record FStart : Double; FEnd : Double; end');
  CL.AddTypeS('TNearestPointTarget', '( nptPoint, nptXList, nptYList, nptCustom)');
  CL.AddTypeS('TNearestPointTargets', 'set of TNearestPointTarget');
  SIRegister_TIntervalList(CL);
  CL.AddTypeS('TCaseOfTwo', '( cotNone, cotFirst, cotSecond, cotBoth )');
 // SIRegister_TIndexedComponent(CL);
//  SIRegister_TTypedFPListEnumerator(CL);
 // SIRegister_TIndexedComponentList(CL);
  CL.AddClassN(CL.FindClass('TOBJECT'),'TBroadcaster');
  //SIRegister_TListener(CL);
  //SIRegister_TBroadcaster(CL);
  //SIRegister_TDrawDataItem(CL);
  //CL.AddTypeS('TDrawDataItemClass', 'class of TDrawDataItem');
  //SIRegister_TDrawDataRegistry(CL);
  //SIRegister_TPublishedIntegerSet(CL);
  //SIRegister_THistory(CL);
  //CL.AddTypeS('PStr', '^String // will not work');
  //SIRegister_TClassRegistryItem(CL);
  //SIRegister_TClassRegistry(CL);
 CL.AddConstantN('PUB_INT_SET_ALL','String').SetString( '');
 CL.AddConstantN('PUB_INT_SET_EMPTY','String').SetString( '-');
 CL.AddConstantN('ORIENTATION_UNITS_PER_DEG','LongInt').SetInt( 10);
 CL.AddDelphiFunction('Function BoundsSize( ALeft, ATop : Integer; ASize : TSize) : TRect');
 CL.AddDelphiFunction('Function Deg16ToRad( ADeg16 : Integer) : Double');
 CL.AddDelphiFunction('Function DoubleInterval( AStart, AEnd : Double) : TDoubleInterval');
 CL.AddDelphiFunction('Procedure Exchange0( var A, B : Integer);');
 CL.AddDelphiFunction('Procedure Exchange1( var A, B : Double);');
 CL.AddDelphiFunction('Procedure Exchange2( var A, B : TDoublePoint);');
 CL.AddDelphiFunction('Procedure Exchange3( var A, B : String);');
 CL.AddDelphiFunction('Function FormatIfNotEmpty( AFormat, AStr : String) : String');
 CL.AddDelphiFunction('Function IfThen4( ACond : Boolean; ATrue, AFalse : TObject) : TObject;');
 CL.AddDelphiFunction('Function TAInterpolateRGB( AColor1, AColor2 : Integer; ACoeff : Double) : Integer');
 CL.AddDelphiFunction('Function IntToColorHex( AColor : Integer) : String');
 CL.AddDelphiFunction('Function IsEquivalent( const A1, A2 : Double) : Boolean');
 CL.AddDelphiFunction('Function IsNan5( const APoint : TDoublePoint) : Boolean;');
 CL.AddDelphiFunction('Function NumberOr( ANum : Double; ADefault : Double) : Double');
 CL.AddDelphiFunction('Function OrientToRad( AOrient : Integer) : Double');
 CL.AddDelphiFunction('Function RadToDeg16( ARad : Double) : Integer');
 CL.AddDelphiFunction('Function RadToOrient( ARad : Double) : Integer');
 CL.AddDelphiFunction('Function RoundChecked( A : Double) : Integer');
 CL.AddDelphiFunction('Procedure TASetPropDefaults( AObject : TPersistent; APropNames : array of String)');
 CL.AddDelphiFunction('Function TASplit( AString : String; ADest : TStrings; ADelimiter : Char) : TStrings');
 CL.AddDelphiFunction('Function StrToFloatDefSep( const AStr : String) : Double');
 //CL.AddDelphiFunction('Procedure Unused( const A1)');
 //CL.AddDelphiFunction('Procedure Unused( const A1, A2)');
 //CL.AddDelphiFunction('Procedure Unused( const A1, A2, A3)');
 CL.AddDelphiFunction('Procedure UpdateMinMax6( AValue : Double; var AMin, AMax : Double);');
 CL.AddDelphiFunction('Procedure UpdateMinMax7( AValue : Integer; var AMin, AMax : Integer);');
 CL.AddDelphiFunction('Function WeightedAverage( AX1, AX2, ACoeff : Double) : Double');
end;

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 7C748DEED176EE303716240DA8ACA9C8D6676EF713C4EE6EE7ED337F0D40160D

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Mar 07 20:56:56 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): A32B3BECFEA379F1474702D1C80ADE0DDADBC0645BD6E72189D58EDAB422E872

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Mar 08 13:42:13 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 2955B78E468DA665BA818E9346C946B067ABFEEBEB44333FF47A1E0A8EE84F51

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Sun Mar 10 16:51:04 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): D0B4D0A01596445DABB47A9A2D1A4A43176F06EA18BEB7AEBCA8EDAFA5F16F11

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Mar 15 15:05:51 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 4E70FD061CDCF6929559E7E09C94FD80484DF9B2C586935F4F18A6988E9675A9

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Wed Mar 20 08:21:56 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Signature Index: 0 (Primary Signature)
Hash of file (sha256): D85C1B5A864E6E95B5F6A32892D33577979832BA9B1207D0CEDCCB80FDA0A347

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 00:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 00:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 00:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Thu Mar 21 16:25:12 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 01:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 01:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sun May 08 08:45:38 2033
            SHA1 hash: CA3E8CFD7CFD329A99359A9A38F86185F0B01C4A


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): E1159C29D2773248FFD9D0C7A36789D3F14C8A56DF08B08AAD346C3A420BADBF

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 01:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 01:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 01:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Tue Apr 16 15:55:47 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 02:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 02:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6 - 202311
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sat Dec 09 19:13:40 2034
            SHA1 hash: B39F0BD99E6437DB70F4FB7D0E3A8CE5FFF5165B


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0

Verifying: maXbox5.exe

Signature Index: 0 (Primary Signature)
Hash of file (sha256): 8F874F811D15C5DE3FCB323B18A07E43AC16965772277D057DA0C05130FB3818

Signing Certificate Chain:
    Issued to: maXboxCertAuth
    Issued by: maXboxCertAuth
    Expires:   Sun Jan 01 01:59:59 2040
    SHA1 hash: 6F83207B500DCC0E32A719599CBC6BD7E6B2A04D

        Issued to: maXbox4signer
        Issued by: maXboxCertAuth
        Expires:   Sun Jan 01 01:59:59 2040
        SHA1 hash: 6A89501B76D47C189A60BF1070BAA2FBFD38D7D7

            Issued to: maXbox4exe
            Issued by: maXbox4signer
            Expires:   Sun Jan 01 01:59:59 2040
            SHA1 hash: F0EB0CA218C5707FAC78921F81092CECA12AD0E9

The signature is timestamped: Fri Apr 19 13:50:47 2024
Timestamp Verified by:
    Issued to: GlobalSign
    Issued by: GlobalSign
    Expires:   Sun Dec 10 02:00:00 2034
    SHA1 hash: 8094640EB5A7A1CA119C1FDDD59F810263A7FBD1

        Issued to: GlobalSign Timestamping CA - SHA384 - G4
        Issued by: GlobalSign
        Expires:   Sun Dec 10 02:00:00 2034
        SHA1 hash: F585500925786F88E721D235240A2452AE3D23F9

            Issued to: Globalsign TSA for CodeSign1 - R6 - 202311
            Issued by: GlobalSign Timestamping CA - SHA384 - G4
            Expires:   Sat Dec 09 19:13:40 2034
            SHA1 hash: B39F0BD99E6437DB70F4FB7D0E3A8CE5FFF5165B


Successfully verified: maXbox5.exe

Number of files successfully Verified: 1
Number of warnings: 0
Number of errors: 0


Zodiacal symbols
See also Asian zodiacal symbols among the animal symbols
in the range 1F400-1F418.
2648 ♈ ARIES
→ 1F40F 🐏  ram
2649 ♉ TAURUS
264A ♊ GEMINI
264B ♋ CANCER
→ 1F980 🦀  crab
264C ♌ LEO
→ 1F981 🦁  lion face
264D ♍ VIRGO
= minim (alternate glyph)
264E ♎ LIBRA
→ 2696 ⚖  scales
→ 1F75E 🝞  alchemical symbol for sublimation
264F ♏ SCORPIUS
= Scorpio
= minim, drop
→ 1F982 🦂  scorpion
2650 ♐ SAGITTARIUS
→ 1F3F9 🏹  bow and arro this end send2 plus: 㼿  this end send2 plus: ??


