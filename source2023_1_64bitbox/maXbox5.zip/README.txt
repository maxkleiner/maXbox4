maXbox5 alpha version 5.0.1.20
------------------------------------------------------
This file was provided by: https://github.com/maxkleiner/maXbox4/tree/master/source2023_1_64bitbox

If you downloaded it from somewhere else, please let us know: maxkleiner1@gmail.com

Viruscheck as clean at:
https://www.virustotal.com/gui/file/5af156d782e755b35fccd72dcb4cea8729c50c332fc00e69272028297bf2373d/details

The individual DLL files like dmath64.dll are provided free of charge with the understanding that the user is familiar with their use.

If you need further information, please see:
https://maxbox4.wordpress.com/
or ask your question in the forum:
https://github.com/maxkleiner/maXbox4/issues
https://forum.dll-files.com/

DISCLAIMER AND LIMITATION OF LIABILITY

The Following Refers to all Files with the Extension of "dll" or dlls compressed as "zip" or files as "exe" or compressed as "zip".

All files are provided on an as is basis. No guarantees or warranties are given or implied. Downloading files from this site is free of charge and the user assumes all risks of any damages that may occur, including but not limited to loss of data, damages to hardware, or loss of business profits. We do our best to ensure that all files are virus-free using available means. However, all files have not been tested for functionality or contamination. Many have been sent to us by visitors like yourself. Thus, we suggest that you do a virus scan using an up-to-date version of an anti-virus program before use. Please use at your own risk.
